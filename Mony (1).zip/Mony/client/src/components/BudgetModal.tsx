import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getAuthHeaders } from "@/lib/auth";

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingBudget?: {
    id: number;
    amount: string;
    period: string;
    alertThreshold: number;
    categoryName: string;
  } | null;
}

interface Category {
  id: number;
  name: string;
  icon: string;
  color: string;
}

export default function BudgetModal({ isOpen, onClose, editingBudget }: BudgetModalProps) {
  const [formData, setFormData] = useState({
    categoryId: "",
    amount: "",
    period: "monthly",
    alertThreshold: "80",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    },
  });

  // Populate form when editing a budget
  useEffect(() => {
    if (editingBudget && categories.length > 0) {
      const category = categories.find(cat => cat.name === editingBudget.categoryName);
      const newFormData = {
        categoryId: category?.id.toString() || "",
        amount: parseFloat(editingBudget.amount).toString(),
        period: editingBudget.period,
        alertThreshold: editingBudget.alertThreshold.toString(),
      };
      
      // Only update if the data is actually different
      if (formData.categoryId !== newFormData.categoryId || 
          formData.amount !== newFormData.amount ||
          formData.period !== newFormData.period ||
          formData.alertThreshold !== newFormData.alertThreshold) {
        setFormData(newFormData);
      }
    } else if (!editingBudget && (formData.categoryId || formData.amount)) {
      setFormData({
        categoryId: "",
        amount: "",
        period: "monthly",
        alertThreshold: "80",
      });
    }
  }, [editingBudget, categories]);

  const createBudgetMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const now = new Date();
      const startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      const endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);

      const method = editingBudget ? "PUT" : "POST";
      const url = editingBudget ? `/api/budgets/${editingBudget.id}` : "/api/budgets";

      const response = await apiRequest(url, method, {
        ...data,
        categoryId: parseInt(data.categoryId),
        alertThreshold: parseInt(data.alertThreshold),
        startDate: startDate,
        endDate: endDate,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: editingBudget ? "Presupuesto actualizado" : "Presupuesto creado",
        description: editingBudget ? "Tu presupuesto ha sido actualizado exitosamente." : "Tu presupuesto ha sido creado exitosamente.",
      });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo crear el presupuesto. Por favor intenta de nuevo.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setFormData({
      categoryId: "",
      amount: "",
      period: "monthly",
      alertThreshold: "80",
    });
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.categoryId) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos obligatorios.",
        variant: "destructive",
      });
      return;
    }

    createBudgetMutation.mutate(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="app-text">
            {editingBudget ? "Editar Presupuesto" : "Crear Nuevo Presupuesto"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="category" className="text-sm font-medium app-text mb-2 block">
              Categoría *
            </Label>
            <Select
              value={formData.categoryId}
              onValueChange={(value) => setFormData({ ...formData, categoryId: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar una categoría" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="amount" className="text-sm font-medium app-text mb-2 block">
              Monto del Presupuesto *
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="0.00"
                className="pl-8"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="period" className="text-sm font-medium app-text mb-2 block">
              Período del Presupuesto
            </Label>
            <Select
              value={formData.period}
              onValueChange={(value) => setFormData({ ...formData, period: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weekly">Semanal</SelectItem>
                <SelectItem value="monthly">Mensual</SelectItem>
                <SelectItem value="yearly">Anual</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="alertThreshold" className="text-sm font-medium app-text mb-2 block">
              Umbral de Alerta (%)
            </Label>
            <Input
              id="alertThreshold"
              type="number"
              min="1"
              max="100"
              placeholder="80"
              value={formData.alertThreshold}
              onChange={(e) => setFormData({ ...formData, alertThreshold: e.target.value })}
            />
            <p className="text-xs text-gray-500 mt-1">
              Recibe notificaciones cuando alcances este porcentaje de tu presupuesto
            </p>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button type="button" variant="outline" className="flex-1" onClick={handleClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="flex-1" 
              disabled={createBudgetMutation.isPending}
            >
              {createBudgetMutation.isPending 
                ? (editingBudget ? "Actualizando..." : "Creando...") 
                : (editingBudget ? "Actualizar Presupuesto" : "Crear Presupuesto")
              }
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

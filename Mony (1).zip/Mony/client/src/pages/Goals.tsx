import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Target, Calendar, DollarSign, Trash2, Edit, PiggyBank } from "lucide-react";
import { getAuthHeaders } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Goal {
  id: number;
  name: string;
  targetAmount: string;
  currentAmount: string;
  description: string;
  targetDate: string;
  createdAt: string;
}

export default function Goals() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isContributeModalOpen, setIsContributeModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [contributingGoal, setContributingGoal] = useState<Goal | null>(null);
  const [contributionAmount, setContributionAmount] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    targetAmount: "",
    currentAmount: "",
    description: "",
    targetDate: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Format currency function for Chilean Pesos
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const { data: goals = [], isLoading } = useQuery<Goal[]>({
    queryKey: ["/api/goals"],
    queryFn: async () => {
      const response = await fetch("/api/goals", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch goals");
      return response.json();
    },
  });

  const createGoalMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("/api/goals", "POST", {
        ...data,
        targetDate: new Date(data.targetDate),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({
        title: "Meta creada",
        description: "Tu meta financiera ha sido creada exitosamente.",
      });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo crear la meta. Por favor intenta de nuevo.",
        variant: "destructive",
      });
    },
  });

  const updateGoalMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & typeof formData) => {
      const response = await apiRequest(`/api/goals/${id}`, "PUT", {
        ...data,
        targetDate: new Date(data.targetDate),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({
        title: "Meta actualizada",
        description: "Tu meta financiera ha sido actualizada exitosamente.",
      });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar la meta. Por favor intenta de nuevo.",
        variant: "destructive",
      });
    },
  });

  const contributeGoalMutation = useMutation({
    mutationFn: async ({ goalId, amount }: { goalId: number; amount: string }) => {
      const response = await apiRequest(`/api/goals/${goalId}/contribute`, "POST", {
        amount: parseFloat(amount),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Aporte realizado",
        description: "Tu contribución ha sido registrada exitosamente como gasto.",
      });
      setIsContributeModalOpen(false);
      setContributionAmount("");
      setContributingGoal(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo procesar el aporte.",
        variant: "destructive",
      });
    },
  });

  const deleteGoalMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest(`/api/goals/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({
        title: "Meta eliminada",
        description: "La meta ha sido eliminada exitosamente.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo eliminar la meta.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setFormData({
      name: "",
      targetAmount: "",
      currentAmount: "",
      description: "",
      targetDate: "",
    });
    setEditingGoal(null);
    setIsModalOpen(false);
  };

  const handleEdit = (goal: Goal) => {
    setEditingGoal(goal);
    setFormData({
      name: goal.name,
      targetAmount: goal.targetAmount,
      currentAmount: goal.currentAmount,
      description: goal.description,
      targetDate: new Date(goal.targetDate).toISOString().split('T')[0],
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.targetAmount || !formData.targetDate) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos obligatorios.",
        variant: "destructive",
      });
      return;
    }

    if (editingGoal) {
      updateGoalMutation.mutate({ id: editingGoal.id, ...formData });
    } else {
      createGoalMutation.mutate(formData);
    }
  };

  const calculateProgress = (current: string, target: string) => {
    const currentNum = parseFloat(current) || 0;
    const targetNum = parseFloat(target) || 1;
    return Math.min((currentNum / targetNum) * 100, 100);
  };

  const getDaysLeft = (targetDate: string) => {
    const target = new Date(targetDate);
    const today = new Date();
    const diffTime = target.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  if (isLoading) {
    return (
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">Metas Financieras</h1>
          <p className="text-muted-foreground">Establece y sigue el progreso de tus objetivos financieros</p>
        </div>
        <Button
          onClick={() => setIsModalOpen(true)}
          className="mt-4 sm:mt-0 bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nueva Meta
        </Button>
      </div>

      {/* Goals Grid */}
      {goals.length === 0 ? (
        <Card className="bg-card border-border">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Target className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-card-foreground mb-2">No tienes metas financieras</h3>
            <p className="text-muted-foreground text-center mb-6">
              Crea tu primera meta financiera para comenzar a ahorrar con propósito
            </p>
            <Button
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Crear Primera Meta
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal) => {
            const progress = calculateProgress(goal.currentAmount, goal.targetAmount);
            const daysLeft = getDaysLeft(goal.targetDate);
            const isOverdue = daysLeft < 0;
            const isNearDeadline = daysLeft <= 30 && daysLeft >= 0;

            return (
              <Card key={goal.id} className="bg-card border-border hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-card-foreground text-lg mb-1">{goal.name}</CardTitle>
                      <p className="text-sm text-muted-foreground line-clamp-2">{goal.description}</p>
                    </div>
                    <div className="flex space-x-1 ml-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(goal)}
                        className="h-8 w-8"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteGoalMutation.mutate(goal.id)}
                        className="h-8 w-8 text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground">Progreso</span>
                      <span className="text-sm font-medium text-card-foreground">{progress.toFixed(1)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Actual</p>
                      <p className="font-semibold text-card-foreground">{formatCurrency(parseFloat(goal.currentAmount || "0"))}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Meta</p>
                      <p className="font-semibold text-card-foreground">{formatCurrency(parseFloat(goal.targetAmount))}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-border">
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        {new Date(goal.targetDate).toLocaleDateString('es-ES')}
                      </span>
                    </div>
                    <Badge
                      variant="secondary"
                      className={`${
                        isOverdue
                          ? "bg-red-50 text-red-700"
                          : isNearDeadline
                          ? "bg-yellow-50 text-yellow-700"
                          : "bg-green-50 text-green-700"
                      }`}
                    >
                      {isOverdue
                        ? `${Math.abs(daysLeft)} días vencido`
                        : daysLeft === 0
                        ? "Hoy"
                        : `${daysLeft} días restantes`}
                    </Badge>
                  </div>

                  <div className="pt-3">
                    <Button
                      onClick={() => {
                        setContributingGoal(goal);
                        setIsContributeModalOpen(true);
                      }}
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                      size="sm"
                    >
                      <PiggyBank className="h-4 w-4 mr-2" />
                      Aportar Dinero
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Goal Modal */}
      <Dialog open={isModalOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="app-text">
              {editingGoal ? "Editar Meta" : "Nueva Meta Financiera"}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-sm font-medium app-text mb-2 block">
                Nombre de la Meta *
              </Label>
              <Input
                id="name"
                placeholder="ej. Fondo de emergencia, Vacaciones, Auto nuevo"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="targetAmount" className="text-sm font-medium app-text mb-2 block">
                  Monto Meta *
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    id="targetAmount"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    className="pl-8"
                    value={formData.targetAmount}
                    onChange={(e) => setFormData({ ...formData, targetAmount: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="currentAmount" className="text-sm font-medium app-text mb-2 block">
                  Monto Actual
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    id="currentAmount"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    className="pl-8"
                    value={formData.currentAmount}
                    onChange={(e) => setFormData({ ...formData, currentAmount: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="targetDate" className="text-sm font-medium app-text mb-2 block">
                Fecha Meta *
              </Label>
              <Input
                id="targetDate"
                type="date"
                value={formData.targetDate}
                onChange={(e) => setFormData({ ...formData, targetDate: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-sm font-medium app-text mb-2 block">
                Descripción (Opcional)
              </Label>
              <Textarea
                id="description"
                placeholder="Describe tu meta financiera..."
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="flex space-x-3 pt-4">
              <Button type="button" variant="outline" className="flex-1" onClick={handleClose}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                className="flex-1" 
                disabled={createGoalMutation.isPending || updateGoalMutation.isPending}
              >
                {createGoalMutation.isPending || updateGoalMutation.isPending 
                  ? (editingGoal ? "Actualizando..." : "Creando...") 
                  : (editingGoal ? "Actualizar Meta" : "Crear Meta")
                }
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Contribution Modal */}
      <Dialog open={isContributeModalOpen} onOpenChange={setIsContributeModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="app-text">
              Aportar a Meta: {contributingGoal?.name}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={(e) => {
            e.preventDefault();
            if (contributingGoal && contributionAmount) {
              contributeGoalMutation.mutate({
                goalId: contributingGoal.id,
                amount: contributionAmount
              });
            }
          }} className="space-y-4">
            <div>
              <Label htmlFor="contributionAmount" className="text-sm font-medium app-text mb-2 block">
                Monto a Aportar *
              </Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                <Input
                  id="contributionAmount"
                  type="number"
                  min="1"
                  step="1"
                  placeholder="50000"
                  className="pl-8"
                  value={contributionAmount}
                  onChange={(e) => setContributionAmount(e.target.value)}
                  required
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Este monto se registrará como gasto en tu dashboard
              </p>
            </div>

            {contributingGoal && (
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Progreso actual:</p>
                <p className="font-medium">
                  {formatCurrency(parseFloat(contributingGoal.currentAmount || "0"))} / {formatCurrency(parseFloat(contributingGoal.targetAmount))}
                </p>
                <Progress 
                  value={calculateProgress(contributingGoal.currentAmount, contributingGoal.targetAmount)} 
                  className="h-2 mt-2" 
                />
              </div>
            )}

            <div className="flex space-x-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                className="flex-1" 
                onClick={() => {
                  setIsContributeModalOpen(false);
                  setContributionAmount("");
                  setContributingGoal(null);
                }}
              >
                Cancelar
              </Button>
              <Button 
                type="submit" 
                className="flex-1 bg-green-600 hover:bg-green-700" 
                disabled={contributeGoalMutation.isPending || !contributionAmount}
              >
                {contributeGoalMutation.isPending ? "Procesando..." : "Realizar Aporte"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
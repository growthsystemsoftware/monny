import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowUpIcon, 
  ArrowDownIcon, 
  PiggyBankIcon, 
  TargetIcon,
  Plus,
  Wallet,
  TrendingUp,
  Download,
  AlertTriangle,
  TriangleAlert
} from "lucide-react";
import { getAuthHeaders } from "@/lib/auth";
import TransactionModal from "@/components/TransactionModal";
import BudgetModal from "@/components/BudgetModal";
import GoalModal from "@/components/GoalModal";
import { IncomeExpenseChart, CategoryChart } from "@/components/Charts";
import DemoDataButton from "@/components/DemoDataButton";
import { useState } from "react";

interface DashboardStats {
  totalIncome: number;
  totalExpenses: number;
  netSavings: number;
  budgetUsed: number;
  totalBudget: number;
  budgetPercentage: number;
  goalContributions: number;
  incomeChange?: number;
  expenseChange?: number;
  savingsChange?: number;
  budgetChange?: number;
}

interface Transaction {
  id: number;
  description: string;
  amount: string;
  type: 'income' | 'expense';
  date: string;
  categoryName?: string;
  categoryIcon?: string;
}

interface BudgetAlert {
  id: number;
  categoryName: string;
  spent: number;
  budget: number;
  percentage: number;
  isOverBudget: boolean;
}

export default function Dashboard() {
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState("1M");

  // Format currency function for Chilean Pesos
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats/dashboard", selectedPeriod],
    queryFn: async () => {
      const response = await fetch(`/api/stats/dashboard?period=${selectedPeriod}`, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch dashboard stats");
      return response.json();
    },
  });

  const { data: recentTransactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions/recent"],
    queryFn: async () => {
      const response = await fetch("/api/transactions?limit=5", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch recent transactions");
      return response.json();
    },
  });

  const { data: budgetAlerts = [] } = useQuery<BudgetAlert[]>({
    queryKey: ["/api/budgets/alerts"],
    queryFn: async () => {
      const response = await fetch("/api/budgets/alerts", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch budget alerts");
      return response.json();
    },
  });

  if (statsLoading) {
    return (
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Dashboard Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Panel Financiero</h1>
            <p className="text-muted-foreground">¡Bienvenido de vuelta! Aquí está tu resumen financiero.</p>
          </div>
          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            {/* Period Selector */}
            <div className="flex space-x-1 bg-muted rounded-lg p-1">
              {[
                { value: "7D", label: "7 días" },
                { value: "1M", label: "1 mes" },
                { value: "6M", label: "6 meses" },
                { value: "1Y", label: "1 año" }
              ].map((period) => (
                <Button
                  key={period.value}
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedPeriod(period.value)}
                  className={`text-xs ${
                    selectedPeriod === period.value
                      ? "bg-background text-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {period.label}
                </Button>
              ))}
            </div>
            <DemoDataButton />
          </div>
        </div>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                <ArrowUpIcon className="h-6 w-6 text-green-600" />
              </div>
              <Badge variant="secondary" className={`${
                (stats?.incomeChange || 0) >= 0 
                  ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400" 
                  : "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400"
              }`}>
                {(stats?.incomeChange || 0) >= 0 ? '+' : ''}{Math.round(stats?.incomeChange || 0)}%
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Ingresos Totales</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(stats?.totalIncome || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-red-50 dark:bg-red-900/20 rounded-lg flex items-center justify-center">
                <ArrowDownIcon className="h-6 w-6 text-red-600" />
              </div>
              <Badge variant="secondary" className={`${
                (stats?.expenseChange || 0) >= 0 
                  ? "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400" 
                  : "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400"
              }`}>
                {(stats?.expenseChange || 0) >= 0 ? '+' : ''}{Math.round(stats?.expenseChange || 0)}%
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Gastos Totales</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(stats?.totalExpenses || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                <PiggyBankIcon className="h-6 w-6 text-green-600" />
              </div>
              <Badge variant="secondary" className={`${
                (stats?.savingsChange || 0) >= 0 
                  ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400" 
                  : "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400"
              }`}>
                {(stats?.savingsChange || 0) >= 0 ? '+' : ''}{Math.round(stats?.savingsChange || 0)}%
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Saldo Total</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(stats?.netSavings || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-purple-50 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                <TargetIcon className="h-6 w-6 text-purple-600" />
              </div>
              <Badge variant="secondary" className="bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400">
                Metas
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Dinero en Metas</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(stats?.goalContributions || 0)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Total contribuido en el período
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg flex items-center justify-center">
                <Wallet className="h-6 w-6 text-yellow-600" />
              </div>
              <Badge variant="secondary" className={`${
                (stats?.budgetChange || 0) >= 0 
                  ? "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400" 
                  : "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400"
              }`}>
                {(stats?.budgetChange || 0) >= 0 ? '+' : ''}{Math.round(stats?.budgetChange || 0)}%
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Presupuesto Usado</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(stats?.budgetUsed || 0)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Charts */}
        <div className="lg:col-span-2 space-y-6">
          <IncomeExpenseChart />
          <CategoryChart />
        </div>

        {/* Right Column - Quick Actions and Recent Activity */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Acciones Rápidas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                className="w-full justify-between bg-blue-600 hover:bg-blue-700"
                onClick={() => setIsTransactionModalOpen(true)}
              >
                <div className="flex items-center space-x-3">
                  <Plus className="h-4 w-4" />
                  <span>Agregar Transacción</span>
                </div>
                <ArrowUpIcon className="h-4 w-4 rotate-45" />
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={() => setIsBudgetModalOpen(true)}
              >
                <div className="flex items-center space-x-3">
                  <Wallet className="h-4 w-4" />
                  <span>Crear Presupuesto</span>
                </div>
                <ArrowUpIcon className="h-4 w-4 rotate-45" />
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={() => setIsGoalModalOpen(true)}
              >
                <div className="flex items-center space-x-3">
                  <TargetIcon className="h-4 w-4" />
                  <span>Establecer Meta Financiera</span>
                </div>
                <ArrowUpIcon className="h-4 w-4 rotate-45" />
              </Button>
              
              <Button variant="outline" className="w-full justify-between">
                <div className="flex items-center space-x-3">
                  <Download className="h-4 w-4" />
                  <span>Exportar Datos</span>
                </div>
                <ArrowUpIcon className="h-4 w-4 rotate-45" />
              </Button>
            </CardContent>
          </Card>

          {/* Budget Alerts */}
          {budgetAlerts.length > 0 && (
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-card-foreground">Alertas de Presupuesto</CardTitle>
                <Badge variant="secondary" className="bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400">
                  {budgetAlerts.length} Activas
                </Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                {budgetAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-3 rounded-lg border ${
                      alert.isOverBudget
                        ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800"
                        : "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800"
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      {alert.isOverBudget ? (
                        <TriangleAlert className="h-4 w-4 text-red-600 mt-0.5" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-yellow-600 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <p className="text-sm font-medium app-text">
                          {alert.categoryName} {alert.isOverBudget ? "Sobre Presupuesto" : "Alerta de Presupuesto"}
                        </p>
                        <p className="text-xs text-gray-600 mt-1">
                          {alert.isOverBudget
                            ? `Has excedido tu presupuesto por ${formatCurrency(alert.spent - alert.budget)}`
                            : `Has gastado ${alert.percentage}% de tu presupuesto`}
                        </p>
                        <div className="flex items-center mt-2">
                          <Progress 
                            value={Math.min(alert.percentage, 100)} 
                            className="flex-1 mr-3"
                          />
                          <span className={`text-xs font-medium ${
                            alert.isOverBudget ? "text-red-600" : "text-yellow-600"
                          }`}>
                            {formatCurrency(alert.spent)}/{formatCurrency(alert.budget)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Recent Transactions */}
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-card-foreground">Transacciones Recientes</CardTitle>
              <Button variant="outline" size="sm">Ver Todas</Button>
            </CardHeader>
            <CardContent>
              {recentTransactions.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-gray-500">No hay transacciones aún</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-2"
                    onClick={() => setIsTransactionModalOpen(true)}
                  >
                    Añadir tu primera transacción
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentTransactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-3 hover:bg-muted rounded-lg transition-colors cursor-pointer"
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          transaction.type === 'income' ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'
                        }`}>
                          <TrendingUp className={`h-4 w-4 ${
                            transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`} />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-card-foreground">{transaction.description}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(transaction.date).toLocaleDateString('es-CL')}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-semibold ${
                          transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {transaction.type === 'income' ? '+' : '-'}{formatCurrency(parseFloat(transaction.amount))}
                        </p>
                        <p className="text-xs text-muted-foreground">{transaction.categoryName}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Modals */}
      <TransactionModal 
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
      />
      <BudgetModal 
        isOpen={isBudgetModalOpen}
        onClose={() => setIsBudgetModalOpen(false)}
      />
      <GoalModal 
        isOpen={isGoalModalOpen}
        onClose={() => setIsGoalModalOpen(false)}
      />
    </div>
  );
}

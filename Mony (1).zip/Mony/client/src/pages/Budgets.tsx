import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Plus, Wallet, AlertTriangle, CheckCircle, Trash2, Edit } from "lucide-react";
import { getAuthHeaders } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import BudgetModal from "@/components/BudgetModal";

interface Budget {
  id: number;
  amount: string;
  period: string;
  alertThreshold: number;
  categoryName: string;
  categoryColor: string;
  spent: number;
  remaining: number;
  percentage: number;
  isOverBudget: boolean;
  daysLeft: number;
}

export default function Budgets() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Format currency function for Chilean Pesos
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const { data: budgets = [], isLoading } = useQuery<Budget[]>({
    queryKey: ["/api/budgets"],
    queryFn: async () => {
      const response = await fetch("/api/budgets", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch budgets");
      return response.json();
    },
  });

  const deleteBudgetMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest(`/api/budgets/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Budget deleted",
        description: "The budget has been successfully deleted.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete budget.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteBudget = (id: number) => {
    if (window.confirm("¿Estás seguro de que quieres eliminar este presupuesto?")) {
      deleteBudgetMutation.mutate(id);
    }
  };

  const getBudgetStatus = (budget: Budget) => {
    if (budget.isOverBudget) return { status: "over", color: "text-red-600", bgColor: "bg-red-50" };
    if (budget.percentage >= budget.alertThreshold) return { status: "warning", color: "text-yellow-600", bgColor: "bg-yellow-50" };
    return { status: "good", color: "text-green-600", bgColor: "bg-green-50" };
  };

  if (isLoading) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">Presupuestos</h1>
          <p className="text-muted-foreground">Establece límites de gasto y rastrea tu progreso</p>
        </div>
        <Button onClick={() => setIsModalOpen(true)} className="mt-4 sm:mt-0">
          <Plus className="h-4 w-4 mr-2" />
          Crear Presupuesto
        </Button>
      </div>

      {/* Budget Overview */}
      {budgets.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                  <Wallet className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Presupuestos</p>
                  <p className="text-2xl font-semibold text-card-foreground">{budgets.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">En Progreso</p>
                  <p className="text-2xl font-semibold app-text">
                    {budgets.filter(b => !b.isOverBudget && b.percentage < b.alertThreshold).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-red-50 dark:bg-red-900/20 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Sobre Presupuesto</p>
                  <p className="text-2xl font-semibold text-card-foreground">
                    {budgets.filter(b => b.isOverBudget).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Budget Cards */}
      {budgets.length === 0 ? (
        <Card className="bg-card border-border">
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Wallet className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-card-foreground mb-2">Aún no tienes presupuestos</h3>
            <p className="text-muted-foreground mb-6">
              Crea tu primer presupuesto para comenzar a rastrear tus gastos y alcanzar tus metas financieras.
            </p>
            <Button onClick={() => setIsModalOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Crear Tu Primer Presupuesto
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {budgets.map((budget) => {
            const { status, color, bgColor } = getBudgetStatus(budget);
            
            return (
              <Card key={budget.id} className="bg-card border-border">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${budget.categoryColor}20` }}
                    >
                      <div 
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: budget.categoryColor }}
                      />
                    </div>
                    <div>
                      <CardTitle className="text-base text-card-foreground">{budget.categoryName}</CardTitle>
                      <p className="text-xs text-muted-foreground capitalize">presupuesto {budget.period === 'monthly' ? 'mensual' : budget.period === 'weekly' ? 'semanal' : 'anual'}</p>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditingBudget(budget);
                        setIsModalOpen(true);
                      }}
                      className="text-muted-foreground hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteBudget(budget.id)}
                      className="text-muted-foreground hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                      disabled={deleteBudgetMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Gastado</span>
                      <span className="text-sm font-medium app-text">
                        {formatCurrency(budget.spent)} / {formatCurrency(parseFloat(budget.amount))}
                      </span>
                    </div>
                    
                    <Progress 
                      value={Math.min(budget.percentage, 100)} 
                      className="h-2"
                    />
                    
                    <div className="flex items-center justify-between">
                      <Badge 
                        variant="outline"
                        className={`${bgColor} ${color} border-current`}
                      >
                        {status === "over" && <AlertTriangle className="h-3 w-3 mr-1" />}
                        {status === "warning" && <AlertTriangle className="h-3 w-3 mr-1" />}
                        {status === "good" && <CheckCircle className="h-3 w-3 mr-1" />}
                        {budget.percentage.toFixed(1)}%
                      </Badge>
                      <span className="text-xs text-gray-500">
                        {budget.daysLeft} días restantes
                      </span>
                    </div>
                    
                    {budget.isOverBudget ? (
                      <div className="text-xs text-red-600 bg-red-50 p-2 rounded">
                        Sobre presupuesto por {formatCurrency(budget.spent - parseFloat(budget.amount))}
                      </div>
                    ) : (
                      <div className="text-xs text-gray-600">
                        {formatCurrency(budget.remaining)} restantes
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <BudgetModal 
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingBudget(null);
        }}
        editingBudget={editingBudget}
      />
    </div>
  );
}

import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/Layout";
import LoadingScreen from "@/components/LoadingScreen";
import Dashboard from "@/pages/Dashboard";
import Transactions from "@/pages/Transactions";
import Budgets from "@/pages/Budgets";
import Goals from "@/pages/Goals";
import Reports from "@/pages/Reports";
import Categories from "@/pages/Categories";
import Settings from "@/pages/Settings";
import AIAssistant from "@/pages/AIAssistant";
import ReceiptScanner from "@/pages/ReceiptScanner";
import Auth from "@/pages/Auth";
import { useState, useEffect } from "react";

function AppRouter() {
  const { user, isLoading } = useAuth();
  const [appInitializing, setAppInitializing] = useState(true);

  useEffect(() => {
    // Show loading screen for at least 1.5 seconds for better UX
    const timer = setTimeout(() => {
      setAppInitializing(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  if (appInitializing || isLoading) {
    return <LoadingScreen isLoading={true} message={appInitializing ? "Iniciando aplicación..." : "Cargando datos..."} />;
  }

  if (!user) {
    return <Auth />;
  }

  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/transactions" component={Transactions} />
        <Route path="/budgets" component={Budgets} />
        <Route path="/goals" component={Goals} />
        <Route path="/reports" component={Reports} />
        <Route path="/categories" component={Categories} />
        <Route path="/ai-assistant" component={AIAssistant} />
        <Route path="/receipt-scanner" component={ReceiptScanner} />
        <Route path="/settings" component={Settings} />
        <Route>
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <h1 className="text-2xl font-semibold app-text mb-2">Página no encontrada</h1>
              <p className="app-neutral">La página que buscas no existe.</p>
            </div>
          </div>
        </Route>
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppRouter />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getFinancialAdvice, ChatMessage, extractReceiptData } from "./openai";
import { insertUserSchema, insertTransactionSchema, insertBudgetSchema, insertCategorySchema, insertGoalSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Create default categories for new user
      await storage.createDefaultCategories(user.id);

      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName 
        }, 
        token 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName 
        }, 
        token 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ 
        id: user.id, 
        username: user.username, 
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Transaction routes
  app.get("/api/transactions", authenticateToken, async (req: any, res) => {
    try {
      const transactions = await storage.getTransactionsByUserId(req.user.userId);
      res.json(transactions);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/transactions/category/:categoryName", authenticateToken, async (req: any, res) => {
    try {
      const categoryName = decodeURIComponent(req.params.categoryName);
      const transactions = await storage.getTransactionsByCategory(req.user.userId, categoryName);
      res.json(transactions);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/transactions", authenticateToken, async (req: any, res) => {
    try {
      const transactionData = insertTransactionSchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const transaction = await storage.createTransaction(transactionData);
      res.json(transaction);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/transactions/:id", authenticateToken, async (req: any, res) => {
    try {
      const transactionId = parseInt(req.params.id);
      console.log("PUT Transaction Request Body:", JSON.stringify(req.body, null, 2));
      
      const transactionData = insertTransactionSchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const transaction = await storage.updateTransaction(transactionId, transactionData, req.user.userId);
      res.json(transaction);
    } catch (error: any) {
      console.log("PUT Transaction Validation Error:", error.message);
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/transactions/:id", authenticateToken, async (req: any, res) => {
    try {
      const transactionId = parseInt(req.params.id);
      await storage.deleteTransaction(transactionId, req.user.userId);
      res.json({ message: "Transaction deleted successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Budget routes
  app.get("/api/budgets", authenticateToken, async (req: any, res) => {
    try {
      const budgets = await storage.getBudgetsByUserId(req.user.userId);
      res.json(budgets);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/budgets", authenticateToken, async (req: any, res) => {
    try {
      const budgetData = insertBudgetSchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const budget = await storage.createBudget(budgetData);
      res.json(budget);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/budgets/:id", authenticateToken, async (req: any, res) => {
    try {
      const budgetId = parseInt(req.params.id);
      console.log("PUT Budget Request Body:", JSON.stringify(req.body, null, 2));
      
      const budgetData = insertBudgetSchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const budget = await storage.updateBudget(budgetId, budgetData, req.user.userId);
      res.json(budget);
    } catch (error: any) {
      console.log("PUT Budget Validation Error:", error.message);
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/budgets/:id", authenticateToken, async (req: any, res) => {
    try {
      const budgetId = parseInt(req.params.id);
      await storage.deleteBudget(budgetId, req.user.userId);
      res.json({ message: "Budget deleted successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Category routes
  app.get("/api/categories", authenticateToken, async (req: any, res) => {
    try {
      const categories = await storage.getCategoriesByUserId(req.user.userId);
      res.json(categories);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/categories", authenticateToken, async (req: any, res) => {
    try {
      const categoryData = insertCategorySchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const category = await storage.createCategory(categoryData);
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/categories/:id", authenticateToken, async (req: any, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const categoryData = insertCategorySchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const category = await storage.updateCategory(categoryId, categoryData, req.user.userId);
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/categories/:id", authenticateToken, async (req: any, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      await storage.deleteCategory(categoryId, req.user.userId);
      res.json({ message: "Categoría eliminada exitosamente" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Goals routes
  app.get("/api/goals", authenticateToken, async (req: any, res) => {
    try {
      const goals = await storage.getGoalsByUserId(req.user.userId);
      res.json(goals);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/goals", authenticateToken, async (req: any, res) => {
    try {
      const goalData = insertGoalSchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const goal = await storage.createGoal(goalData);
      res.json(goal);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/goals/:id", authenticateToken, async (req: any, res) => {
    try {
      const goalId = parseInt(req.params.id);
      console.log("PUT Goal Request Body:", JSON.stringify(req.body, null, 2));
      
      const goalData = insertGoalSchema.parse({
        ...req.body,
        userId: req.user.userId,
      });
      
      const goal = await storage.updateGoal(goalId, goalData, req.user.userId);
      res.json(goal);
    } catch (error: any) {
      console.log("PUT Goal Validation Error:", error.message);
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/goals/:id", authenticateToken, async (req: any, res) => {
    try {
      const goalId = parseInt(req.params.id);
      await storage.deleteGoal(goalId, req.user.userId);
      res.json({ message: "Meta eliminada exitosamente" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/goals/:id/contribute", authenticateToken, async (req: any, res) => {
    try {
      const goalId = parseInt(req.params.id);
      const { amount } = req.body;
      
      if (!amount || parseFloat(amount) <= 0) {
        return res.status(400).json({ message: "El monto debe ser mayor a 0" });
      }

      const result = await storage.contributeToGoal(goalId, parseFloat(amount), req.user.userId);
      res.json(result);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Dashboard stats
  app.get("/api/stats/dashboard", authenticateToken, async (req: any, res) => {
    try {
      const period = req.query.period as string || "1M";
      const stats = await storage.getDashboardStats(req.user.userId, period);
      res.json(stats);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Chart data
  app.get("/api/stats/chart", authenticateToken, async (req: any, res) => {
    try {
      const period = req.query.period as string || "6M";
      const chartData = await storage.getChartData(req.user.userId, period);
      res.json(chartData);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Category stats
  app.get("/api/stats/categories", authenticateToken, async (req: any, res) => {
    try {
      const categoryStats = await storage.getCategoryStats(req.user.userId);
      res.json(categoryStats);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Budget alerts
  app.get("/api/budgets/alerts", authenticateToken, async (req: any, res) => {
    try {
      const alerts = await storage.getBudgetAlerts(req.user.userId);
      res.json(alerts);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Reports
  app.get("/api/reports", authenticateToken, async (req: any, res) => {
    try {
      const period = req.query.period as string || "6months";
      const reportData = await storage.getReportData(req.user.userId, period);
      res.json(reportData);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Demo data endpoints
  app.post("/api/demo/populate", authenticateToken, async (req: any, res) => {
    try {
      await storage.populateDemoData(req.user.userId);
      res.json({ message: "Datos de demostración creados exitosamente" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/demo/clear", authenticateToken, async (req: any, res) => {
    try {
      await storage.clearAllUserData(req.user.userId);
      res.json({ message: "Todos los datos han sido eliminados exitosamente" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Chat history endpoints
  app.get("/api/chat/history", authenticateToken, async (req: any, res) => {
    try {
      const history = await storage.getChatHistory(req.user.userId);
      res.json(history);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/chat/history", authenticateToken, async (req: any, res) => {
    try {
      await storage.clearChatHistory(req.user.userId);
      res.json({ message: "Chat history cleared successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // AI Financial Assistant endpoint
  app.post("/api/ai/chat", authenticateToken, async (req: any, res) => {
    try {
      const { message } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: "Message is required" });
      }

      // Get chat history from database
      const chatHistory = await storage.getChatHistory(req.user.userId);
      
      // Save user message
      await storage.saveChatMessage({
        userId: req.user.userId,
        role: 'user',
        content: message
      });

      const advice = await getFinancialAdvice(
        req.user.userId,
        message,
        chatHistory.map(msg => ({ role: msg.role as 'user' | 'assistant', content: msg.content }))
      );

      // Save assistant response
      await storage.saveChatMessage({
        userId: req.user.userId,
        role: 'assistant',
        content: advice
      });

      res.json({ response: advice });
    } catch (error: any) {
      console.error('AI chat error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Receipt scanning endpoint
  app.post("/api/receipts/extract", authenticateToken, async (req: any, res) => {
    try {
      const { image } = req.body;
      
      if (!image || typeof image !== 'string') {
        return res.status(400).json({ error: "Image data is required" });
      }

      const extractedData = await extractReceiptData(image);
      res.json(extractedData);
    } catch (error: any) {
      console.error('Receipt extraction error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

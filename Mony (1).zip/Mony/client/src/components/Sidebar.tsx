import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  ArrowRightLeft, 
  Wallet, 
  Target, 
  BarChart3, 
  FolderOpen,
  Settings,
  LogOut,
  X,
  Sun,
  Moon,
  Bot,
  Scan
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useState, useEffect } from "react";

interface SidebarProps {
  onClose?: () => void;
}

const navigation = [
  { name: "Inicio", href: "/", icon: LayoutDashboard },
  { name: "Transacciones", href: "/transactions", icon: ArrowRightLeft },
  { name: "Presupuestos", href: "/budgets", icon: Wallet },
  { name: "Metas", href: "/goals", icon: Target },
  { name: "Reportes", href: "/reports", icon: BarChart3 },
  { name: "Categorías", href: "/categories", icon: FolderOpen },
  { name: "Asistente IA", href: "/ai-assistant", icon: Bot },
  { name: "Escaneo de Boletas", href: "/receipt-scanner", icon: Scan },
  { name: "Configuración", href: "/settings", icon: Settings },
];

export default function Sidebar({ onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    // Check if dark mode is enabled on component mount
    const isDarkMode = document.documentElement.classList.contains('dark');
    setIsDark(isDarkMode);
  }, []);

  const handleLogout = () => {
    logout();
    onClose?.();
  };

  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    const newDarkMode = document.documentElement.classList.contains('dark');
    setIsDark(newDarkMode);
    // Save preference to localStorage
    localStorage.setItem('theme', newDarkMode ? 'dark' : 'light');
  };

  return (
    <div className="flex flex-col w-64 bg-background border-r border-border h-full">
      {/* Logo */}
      <div className="flex items-center justify-between h-16 px-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <img 
            src={isDark ? "/logo-blanco.png" : "/logo.png"} 
            alt="Logo" 
            className="h-10 w-auto object-contain"
          />
        </div>
        <div className="flex items-center space-x-2">
          {onClose && (
            <Button variant="ghost" size="icon" onClick={onClose} className="lg:hidden">
              <X className="h-5 w-5" />
            </Button>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.name} href={item.href}>
              <div
                className={`flex items-center px-3 py-2 text-base font-medium rounded-lg transition-colors cursor-pointer ${
                  isActive
                    ? "text-blue-600 bg-blue-50 dark:bg-blue-900/20"
                    : "text-text hover:text-text hover:bg-secondary"
                }`}
                onClick={onClose}
              >
                <Icon className="mr-3 h-4 w-4" />
                {item.name}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* User Profile */}
      <div className="px-4 py-4 border-t border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3 min-w-0 flex-1">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
              {user?.firstName?.[0] || user?.username?.[0] || "U"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-text truncate">
                {user?.firstName && user?.lastName 
                  ? `${user.firstName} ${user.lastName}`
                  : user?.username || "User"
                }
              </p>
              <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleTheme}
            className="w-8 h-8 text-muted-foreground hover:text-foreground"
          >
            {isDark ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleLogout}
          className="w-full justify-start text-text hover:text-text text-base"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Cerrar Sesión
        </Button>
      </div>
    </div>
  );
}

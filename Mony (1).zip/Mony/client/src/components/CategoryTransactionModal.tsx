import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { CategoryIcon } from "./CategoryIcon";
import { getAuthHeaders } from "@/lib/auth";
import { X, Calendar, FileText } from "lucide-react";

interface Transaction {
  id: number;
  description: string;
  amount: string;
  type: 'income' | 'expense';
  date: string;
  notes?: string;
  categoryName?: string;
  categoryIcon?: string;
  categoryColor?: string;
}

interface CategoryTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  categoryName: string;
  categoryColor: string;
}

export default function CategoryTransactionModal({ 
  isOpen, 
  onClose, 
  categoryName,
  categoryColor 
}: CategoryTransactionModalProps) {
  // Format currency function for Chilean Pesos
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Format date function
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CL', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const { data: transactions = [], isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions/category", categoryName],
    queryFn: async () => {
      const response = await fetch(`/api/transactions/category/${encodeURIComponent(categoryName)}`, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch category transactions");
      return response.json();
    },
    enabled: isOpen && !!categoryName,
  });

  const totalAmount = transactions.reduce((sum, transaction) => {
    return sum + parseFloat(transaction.amount);
  }, 0);

  const incomeTransactions = transactions.filter(t => t.type === 'income');
  const expenseTransactions = transactions.filter(t => t.type === 'expense');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl h-[85vh] bg-card border-border p-0">
        {/* Fixed Header */}
        <div className="flex flex-row items-center justify-between p-6 pb-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <div 
              className="w-12 h-12 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: `${categoryColor}20` }}
            >
              <div 
                className="w-6 h-6 rounded"
                style={{ backgroundColor: categoryColor }}
              />
            </div>
            <div>
              <DialogTitle className="text-xl text-card-foreground">
                Transacciones de {categoryName}
              </DialogTitle>
              <DialogDescription className="text-muted-foreground">
                {transactions.length} transacciones • Total: {formatCurrency(totalAmount)}
              </DialogDescription>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Fixed Summary Stats */}
        <div className="px-6 py-4 border-b border-border">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-muted/30 rounded-lg p-3 text-center">
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="text-lg font-semibold text-card-foreground">
                {transactions.length}
              </p>
            </div>
            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-center">
              <p className="text-sm text-green-600 dark:text-green-400">Ingresos</p>
              <p className="text-lg font-semibold text-green-700 dark:text-green-300">
                {incomeTransactions.length}
              </p>
            </div>
            <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-3 text-center">
              <p className="text-sm text-red-600 dark:text-red-400">Gastos</p>
              <p className="text-lg font-semibold text-red-700 dark:text-red-300">
                {expenseTransactions.length}
              </p>
            </div>
          </div>
        </div>

        {/* Scrollable Transaction List */}
        <div className="flex-1 overflow-y-auto p-6">
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="bg-muted/30 rounded-lg p-4 animate-pulse">
                  <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">No hay transacciones para esta categoría</p>
            </div>
          ) : (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="bg-background border border-border rounded-lg p-4 hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 flex-1">
                      <div className="flex-shrink-0">
                        <Badge 
                          variant={transaction.type === 'income' ? 'default' : 'secondary'}
                          className={
                            transaction.type === 'income' 
                              ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300' 
                              : 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300'
                          }
                        >
                          {transaction.type === 'income' ? 'Ingreso' : 'Gasto'}
                        </Badge>
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-card-foreground break-words">
                          {transaction.description}
                        </p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Calendar className="h-3 w-3 text-muted-foreground" />
                          <p className="text-xs text-muted-foreground">
                            {formatDate(transaction.date)}
                          </p>
                        </div>
                        {transaction.notes && (
                          <p className="text-xs text-muted-foreground mt-1 break-words">
                            {transaction.notes}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right ml-4">
                      <p className={`font-semibold ${
                        transaction.type === 'income' 
                          ? 'text-green-600 dark:text-green-400' 
                          : 'text-red-600 dark:text-red-400'
                      }`}>
                        {transaction.type === 'income' ? '+' : '-'}
                        {formatCurrency(parseFloat(transaction.amount))}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
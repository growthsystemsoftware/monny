import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User, 
  Bell, 
  Shield, 
  Palette, 
  Download, 
  Trash2, 
  AlertTriangle,
  Save,
  Eye,
  Database,
  Settings as SettingsIcon,
  Info,
  EyeOff
} from "lucide-react";
import { getAuthHeaders } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [profileData, setProfileData] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    username: user?.username || "",
    email: user?.email || "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [preferences, setPreferences] = useState({
    budgetAlerts: true,
    expenseReminders: true,
    goalProgress: true,
    emailNotifications: false,
    theme: localStorage.getItem("theme") || "light",
    currency: "CLP",
    language: "es",
    dataSharing: false,
  });

  // Simple theme toggle function
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    const isDark = document.documentElement.classList.contains('dark');
    const newTheme = isDark ? 'dark' : 'light';
    setPreferences({ ...preferences, theme: newTheme });
    localStorage.setItem("theme", newTheme);
  };

  // Apply theme changes immediately
  const handleThemeChange = (newTheme: string) => {
    setPreferences({ ...preferences, theme: newTheme });
    localStorage.setItem("theme", newTheme);
    
    // Apply theme to document
    const root = document.documentElement;
    if (newTheme === "dark") {
      root.classList.add("dark");
    } else if (newTheme === "light") {
      root.classList.remove("dark");
    } else if (newTheme === "system") {
      const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      if (isDark) {
        root.classList.add("dark");
      } else {
        root.classList.remove("dark");
      }
    }
  };

  // Initialize theme on component mount
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") || "light";
    handleThemeChange(savedTheme);
  }, []);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("/api/user/profile", "PUT", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Perfil actualizado",
        description: "Tu información personal ha sido actualizada exitosamente.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar el perfil.",
        variant: "destructive",
      });
    },
  });

  const updatePasswordMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("/api/user/password", "PUT", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Contraseña actualizada",
        description: "Tu contraseña ha sido cambiada exitosamente.",
      });
      setProfileData(prev => ({
        ...prev,
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      }));
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar la contraseña.",
        variant: "destructive",
      });
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("/api/user/account", "DELETE");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Cuenta eliminada",
        description: "Tu cuenta ha sido eliminada exitosamente.",
      });
      logout();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo eliminar la cuenta.",
        variant: "destructive",
      });
    },
  });

  const clearDataMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("/api/demo/clear", "DELETE");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Datos eliminados",
        description: "Todos los datos han sido eliminados exitosamente.",
      });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudieron eliminar los datos.",
        variant: "destructive",
      });
    },
  });

  const populateDemoMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("/api/demo/populate", "POST");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Datos de demostración cargados",
        description: "Se han agregado transacciones y datos de ejemplo.",
      });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudieron cargar los datos de demostración.",
        variant: "destructive",
      });
    },
  });

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const { currentPassword, newPassword, confirmPassword, ...profileInfo } = profileData;
    updateProfileMutation.mutate(profileInfo);
  };

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!profileData.currentPassword || !profileData.newPassword) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos de contraseña.",
        variant: "destructive",
      });
      return;
    }

    if (profileData.newPassword !== profileData.confirmPassword) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden.",
        variant: "destructive",
      });
      return;
    }

    if (profileData.newPassword.length < 6) {
      toast({
        title: "Error",
        description: "La nueva contraseña debe tener al menos 6 caracteres.",
        variant: "destructive",
      });
      return;
    }

    updatePasswordMutation.mutate({
      currentPassword: profileData.currentPassword,
      newPassword: profileData.newPassword,
    });
  };

  const handleExportData = () => {
    toast({
      title: "Exportando datos",
      description: "Tu archivo de datos se descargará en breve.",
    });
    // Implement data export logic
  };

  const handleDeleteAccount = () => {
    if (window.confirm("¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.")) {
      deleteAccountMutation.mutate();
    }
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Configuración</h1>
        <p className="text-muted-foreground">Gestiona tu cuenta y personaliza tu experiencia</p>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-5 mb-8">
          <TabsTrigger value="profile" className="flex items-center space-x-2">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Perfil</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Seguridad</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center space-x-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Notificaciones</span>
          </TabsTrigger>
          <TabsTrigger value="appearance" className="flex items-center space-x-2">
            <Palette className="h-4 w-4" />
            <span className="hidden sm:inline">Apariencia</span>
          </TabsTrigger>
          <TabsTrigger value="data" className="flex items-center space-x-2">
            <Database className="h-4 w-4" />
            <span className="hidden sm:inline">Datos</span>
          </TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-card-foreground">
                <User className="h-5 w-5" />
                <span>Información Personal</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileUpdate} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName" className="text-sm font-medium app-text mb-2 block">
                      Nombre
                    </Label>
                    <Input
                      id="firstName"
                      value={profileData.firstName}
                      onChange={(e) => setProfileData({ ...profileData, firstName: e.target.value })}
                      placeholder="Tu nombre"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="text-sm font-medium app-text mb-2 block">
                      Apellido
                    </Label>
                    <Input
                      id="lastName"
                      value={profileData.lastName}
                      onChange={(e) => setProfileData({ ...profileData, lastName: e.target.value })}
                      placeholder="Tu apellido"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="username" className="text-sm font-medium app-text mb-2 block">
                    Nombre de Usuario
                  </Label>
                  <Input
                    id="username"
                    value={profileData.username}
                    onChange={(e) => setProfileData({ ...profileData, username: e.target.value })}
                    placeholder="Nombre de usuario"
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-sm font-medium app-text mb-2 block">
                    Correo Electrónico
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                    placeholder="tu@email.com"
                  />
                </div>
                <Button 
                  type="submit" 
                  disabled={updateProfileMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {updateProfileMutation.isPending ? "Guardando..." : "Guardar Cambios"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-card-foreground">
                <Shield className="h-5 w-5" />
                <span>Cambiar Contraseña</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePasswordUpdate} className="space-y-4">
                <div>
                  <Label htmlFor="currentPassword" className="text-sm font-medium app-text mb-2 block">
                    Contraseña Actual
                  </Label>
                  <Input
                    id="currentPassword"
                    type="password"
                    value={profileData.currentPassword}
                    onChange={(e) => setProfileData({ ...profileData, currentPassword: e.target.value })}
                    placeholder="Tu contraseña actual"
                  />
                </div>
                <div>
                  <Label htmlFor="newPassword" className="text-sm font-medium app-text mb-2 block">
                    Nueva Contraseña
                  </Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={profileData.newPassword}
                    onChange={(e) => setProfileData({ ...profileData, newPassword: e.target.value })}
                    placeholder="Tu nueva contraseña"
                  />
                </div>
                <div>
                  <Label htmlFor="confirmPassword" className="text-sm font-medium app-text mb-2 block">
                    Confirmar Nueva Contraseña
                  </Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={profileData.confirmPassword}
                    onChange={(e) => setProfileData({ ...profileData, confirmPassword: e.target.value })}
                    placeholder="Confirma tu nueva contraseña"
                  />
                </div>
                <Button 
                  type="submit" 
                  disabled={updatePasswordMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Shield className="h-4 w-4 mr-2" />
                  {updatePasswordMutation.isPending ? "Actualizando..." : "Actualizar Contraseña"}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-card-foreground">
                <Shield className="h-5 w-5" />
                <span>Privacidad y Seguridad</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium app-text">Autenticación de Dos Factores</Label>
                  <p className="text-sm app-neutral">Agrega una capa extra de seguridad a tu cuenta</p>
                </div>
                <Badge variant="secondary">Próximamente</Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium app-text">Sesiones Activas</Label>
                  <p className="text-sm app-neutral">Gestiona dispositivos donde has iniciado sesión</p>
                </div>
                <Button variant="outline" size="sm">
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Sesiones
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-card-foreground">
                <Bell className="h-5 w-5" />
                <span>Preferencias de Notificaciones</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium app-text">Alertas de Presupuesto</Label>
                  <p className="text-sm app-neutral">Recibe notificaciones cuando superes tus límites de presupuesto</p>
                </div>
                <Switch checked={preferences.budgetAlerts} onCheckedChange={(checked) => setPreferences({ ...preferences, budgetAlerts: checked })} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium app-text">Recordatorios de Gastos</Label>
                  <p className="text-sm app-neutral">Te recordaremos registrar tus gastos diarios</p>
                </div>
                <Switch checked={preferences.expenseReminders} onCheckedChange={(checked) => setPreferences({ ...preferences, expenseReminders: checked })} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium app-text">Metas Financieras</Label>
                  <p className="text-sm app-neutral">Recibe actualizaciones sobre el progreso de tus metas</p>
                </div>
                <Switch checked={preferences.goalProgress} onCheckedChange={(checked) => setPreferences({ ...preferences, goalProgress: checked })} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium app-text">Notificaciones por Email</Label>
                  <p className="text-sm app-neutral">Recibe resúmenes semanales por correo electrónico</p>
                </div>
                <Switch checked={preferences.emailNotifications} onCheckedChange={(checked) => setPreferences({ ...preferences, emailNotifications: checked })} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance Tab */}
        <TabsContent value="appearance" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-card-foreground">
                <Palette className="h-5 w-5" />
                <span>Tema y Apariencia</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium app-text mb-2 block">Tema</Label>
                <div className="space-y-3">
                  <Select value={preferences.theme} onValueChange={handleThemeChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un tema" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Claro</SelectItem>
                      <SelectItem value="dark">Oscuro</SelectItem>
                      <SelectItem value="system">Sistema</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button 
                    onClick={toggleTheme} 
                    variant="outline" 
                    className="w-full bg-background text-text border-border hover:bg-secondary"
                  >
                    Cambiar Tema
                  </Button>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium app-text mb-2 block">Moneda</Label>
                <Select value={preferences.currency} onValueChange={(value) => setPreferences({ ...preferences, currency: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona una moneda" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CLP">Peso Chileno (CLP)</SelectItem>
                    <SelectItem value="USD">Dólar Americano (USD)</SelectItem>
                    <SelectItem value="EUR">Euro (EUR)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium app-text mb-2 block">Idioma</Label>
                <Select value={preferences.language} onValueChange={(value) => setPreferences({ ...preferences, language: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un idioma" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="es">Español</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Data Tab */}
        <TabsContent value="data" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-card-foreground">
                <Database className="h-5 w-5" />
                <span>Gestión de Datos</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div>
                  <p className="font-medium text-blue-700 dark:text-blue-400">Exportar Datos</p>
                  <p className="text-sm text-blue-600 dark:text-blue-300">
                    Descarga una copia de todos tus datos financieros
                  </p>
                </div>
                <Button onClick={handleExportData} variant="outline" className="border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/40">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div>
                  <p className="font-medium text-green-700 dark:text-green-400">Cargar Datos de Demostración</p>
                  <p className="text-sm text-green-600 dark:text-green-300">
                    Agrega transacciones y datos de ejemplo para probar la aplicación
                  </p>
                </div>
                <Button 
                  onClick={() => populateDemoMutation.mutate()}
                  variant="outline" 
                  className="border-green-200 dark:border-green-800 text-green-600 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-900/40"
                  disabled={populateDemoMutation.isPending}
                >
                  <Database className="h-4 w-4 mr-2" />
                  {populateDemoMutation.isPending ? "Cargando..." : "Cargar Demo"}
                </Button>
              </div>

              <div className="flex items-center justify-between p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <div>
                  <p className="font-medium text-orange-700 dark:text-orange-400">Limpiar Todos los Datos</p>
                  <p className="text-sm text-orange-600 dark:text-orange-300">
                    Elimina todas las transacciones, presupuestos y metas
                  </p>
                </div>
                <Button 
                  onClick={() => {
                    if (window.confirm("¿Estás seguro de que quieres eliminar todos tus datos? Esta acción no se puede deshacer.")) {
                      clearDataMutation.mutate();
                    }
                  }}
                  variant="outline" 
                  className="border-orange-200 text-orange-600 hover:bg-orange-100"
                  disabled={clearDataMutation.isPending}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  {clearDataMutation.isPending ? "Eliminando..." : "Limpiar Datos"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-red-200 dark:border-red-800">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-red-700 dark:text-red-400">
                <AlertTriangle className="h-5 w-5" />
                <span>Zona de Peligro</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                <div>
                  <p className="font-medium text-red-700 dark:text-red-400">Eliminar Cuenta</p>
                  <p className="text-sm text-red-600 dark:text-red-400">
                    Esta acción eliminará permanentemente tu cuenta y todos tus datos
                  </p>
                </div>
                <Button 
                  onClick={handleDeleteAccount} 
                  variant="destructive"
                  disabled={deleteAccountMutation.isPending}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  {deleteAccountMutation.isPending ? "Eliminando..." : "Eliminar Cuenta"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
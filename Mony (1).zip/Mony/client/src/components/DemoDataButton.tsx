export default function DemoDataButton() {
  return null;
}
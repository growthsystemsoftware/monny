import { useState, useRef, useCallback, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { Camera, Upload, Loader2, Check, X, RefreshCw, Smartphone, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useIsMobile } from "@/hooks/use-mobile";

interface ExtractedData {
  amount: string;
  description: string;
  date: string;
  type: 'income' | 'expense';
  merchant?: string;
  suggestedCategory?: string;
  confidence: number;
}

interface Category {
  id: number;
  name: string;
  icon: string;
  color: string;
}

export default function ReceiptScanner() {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<ExtractedData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [editableData, setEditableData] = useState<ExtractedData | null>(null);
  const [currentFacingMode, setCurrentFacingMode] = useState<'environment' | 'user'>('environment');
  
  const isMobile = useIsMobile();
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Start camera stream
  const startCamera = useCallback(async () => {
    console.log('Starting camera...');
    
    // Check if MediaDevices API is supported
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      console.error('MediaDevices API not supported');
      toast({
        title: "Cámara no compatible",
        description: "Tu dispositivo no soporta acceso a la cámara. Puedes subir una imagen desde tu galería.",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('Requesting camera access...');
      let stream;
      
      // Try the current facing mode first
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { exact: currentFacingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
        console.log(`Camera activated with ${currentFacingMode} facing mode`);
      } catch (specificCameraError) {
        console.log(`${currentFacingMode} camera not available, trying fallback`);
        // Fallback to any available camera
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: currentFacingMode === 'environment' ? 'user' : 'environment',
              width: { ideal: 640 },
              height: { ideal: 480 }
            }
          });
          console.log('Fallback camera activated');
        } catch (fallbackError) {
          // Last resort - any camera
          stream = await navigator.mediaDevices.getUserMedia({
            video: true
          });
          console.log('Default camera activated');
        }
      }
      
      console.log('Camera stream obtained:', stream);
      
      if (videoRef.current && stream) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        
        // Force video to play
        videoRef.current.onloadedmetadata = async () => {
          if (videoRef.current) {
            try {
              await videoRef.current.play();
              console.log('Video playing successfully');
            } catch (playError) {
              console.log('Autoplay failed:', playError);
              // Manual play might be required on some browsers
            }
          }
        };
        
        toast({
          title: "Cámara activada",
          description: "La cámara está lista. Usa el botón de captura para tomar la foto.",
        });
      }
    } catch (error: any) {
      console.error('Error accessing camera:', error);
      toast({
        title: "Error de cámara",
        description: `No se pudo acceder a la cámara: ${error?.message || 'Error desconocido'}. Verifica los permisos del navegador.`,
        variant: "destructive"
      });
    }
  }, [toast, currentFacingMode]);

  // Switch camera function
  const switchCamera = useCallback(async () => {
    if (streamRef.current) {
      // Stop current stream
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    // Switch facing mode
    const newFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
    setCurrentFacingMode(newFacingMode);
    
    // Start camera with new facing mode
    setTimeout(startCamera, 100); // Small delay to ensure state update
  }, [currentFacingMode, startCamera]);

  // Stop camera stream
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  }, []);

  // Compress image to reduce file size
  const compressImage = useCallback((canvas: HTMLCanvasElement, maxWidth = 1024, quality = 0.7): string => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    // Calculate new dimensions maintaining aspect ratio
    const { width, height } = canvas;
    let newWidth = width;
    let newHeight = height;

    if (width > maxWidth) {
      newWidth = maxWidth;
      newHeight = (height * maxWidth) / width;
    }

    // Create a new canvas with compressed dimensions
    const compressedCanvas = document.createElement('canvas');
    compressedCanvas.width = newWidth;
    compressedCanvas.height = newHeight;
    
    const compressedCtx = compressedCanvas.getContext('2d');
    if (compressedCtx) {
      compressedCtx.drawImage(canvas, 0, 0, newWidth, newHeight);
      return compressedCanvas.toDataURL('image/jpeg', quality);
    }
    
    return canvas.toDataURL('image/jpeg', quality);
  }, []);

  // Capture photo from camera
  const capturePhoto = useCallback(() => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const compressedImage = compressImage(canvas);
        setCapturedImage(compressedImage);
        stopCamera();
      }
    }
  }, [stopCamera, compressImage]);

  // Handle file upload with compression
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        
        // Create image element to compress
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          if (ctx) {
            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);
            
            const compressedImage = compressImage(canvas);
            setCapturedImage(compressedImage);
          } else {
            setCapturedImage(result);
          }
        };
        img.src = result;
      };
      reader.readAsDataURL(file);
    }
  };

  // Extract data from image using OpenAI Vision
  const extractDataMutation = useMutation({
    mutationFn: async (imageData: string): Promise<ExtractedData> => {
      const response = await apiRequest('/api/receipts/extract', 'POST', {
        image: imageData
      });
      return await response.json();
    },
    onSuccess: (data: ExtractedData) => {
      console.log('Extracted data received:', data);
      setExtractedData(data);
      setEditableData(data);
      setIsProcessing(false);
      
      // Auto-select category if suggestion matches available categories
      if (data.suggestedCategory && categories.length > 0) {
        const matchingCategory = categories.find(cat => 
          cat.name.toLowerCase().includes(data.suggestedCategory!.toLowerCase()) ||
          data.suggestedCategory!.toLowerCase().includes(cat.name.toLowerCase())
        );
        if (matchingCategory) {
          setSelectedCategory(matchingCategory.id.toString());
        }
      }
      
      toast({
        title: "Datos extraídos exitosamente",
        description: "Revisa la información y guarda la transacción",
      });
    },
    onError: (error: any) => {
      setIsProcessing(false);
      
      let errorMessage = "No se pudo extraer la información de la boleta.";
      let errorDetails = "";
      
      // Check for specific error types
      if (error?.message) {
        if (error.message.includes('too large')) {
          errorMessage = "Imagen demasiado grande";
          errorDetails = "La imagen es muy pesada. Intenta con una foto más pequeña o de menor calidad.";
        } else if (error.message.includes('network') || error.message.includes('fetch')) {
          errorMessage = "Error de conexión";
          errorDetails = "Verifica tu conexión a internet e intenta nuevamente.";
        } else if (error.message.includes('API key') || error.message.includes('unauthorized')) {
          errorMessage = "Error de configuración";
          errorDetails = "Hay un problema con la configuración del servicio de IA. Contacta al administrador.";
        } else if (error.message.includes('rate limit')) {
          errorMessage = "Límite de uso alcanzado";
          errorDetails = "Has alcanzado el límite de procesamiento. Intenta más tarde.";
        } else if (error.message.includes('format') || error.message.includes('invalid')) {
          errorMessage = "Formato de imagen no válido";
          errorDetails = "Asegúrate de subir una imagen JPG, PNG o WebP.";
        } else {
          errorDetails = error.message;
        }
      }
      
      toast({
        title: errorMessage,
        description: errorDetails || "Inténtalo de nuevo con una imagen más clara de la boleta.",
        variant: "destructive"
      });
    }
  });

  // Create transaction from extracted data
  const createTransactionMutation = useMutation({
    mutationFn: async (transactionData: any) => {
      return await apiRequest('/api/transactions', 'POST', transactionData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/dashboard'] });
      toast({
        title: "Transacción creada",
        description: "La transacción se ha guardado exitosamente.",
      });
      resetScanner();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo crear la transacción.",
        variant: "destructive"
      });
    }
  });

  // Process captured image
  const processImage = () => {
    if (capturedImage) {
      setIsProcessing(true);
      extractDataMutation.mutate(capturedImage);
    }
  };

  // Reset scanner
  const resetScanner = () => {
    setCapturedImage(null);
    setExtractedData(null);
    setEditableData(null);
    setSelectedCategory("");
    stopCamera();
  };

  // Save transaction
  const saveTransaction = () => {
    if (editableData && selectedCategory) {
      // Ensure date is in correct format
      const dateValue = editableData.date.includes('T') 
        ? editableData.date 
        : `${editableData.date}T12:00:00.000Z`; // Add time component if missing
      
      const transactionData = {
        type: editableData.type,
        amount: editableData.amount,
        description: editableData.description,
        categoryId: parseInt(selectedCategory),
        date: dateValue,
        notes: `Escaneado de boleta${editableData.merchant ? ` - ${editableData.merchant}` : ''}`
      };
      
      console.log('Saving transaction with date:', dateValue);
      createTransactionMutation.mutate(transactionData);
    }
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto min-h-screen flex flex-col">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Escaneo de Boletas</h1>
        <p className="text-muted-foreground">
          Toma una foto de tu boleta o recibo para extraer automáticamente la información financiera
        </p>
      </div>

      <div className="flex-1 grid gap-6 lg:grid-cols-2">
        {/* Camera/Upload Section */}
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Capturar Boleta</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col">
            {!capturedImage ? (
              <div className="flex-1 flex flex-col gap-4">
                {/* Camera preview */}
                <div className="flex-1 bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden relative">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                  <canvas ref={canvasRef} className="hidden" />
                  
                  {/* Camera instructions overlay */}
                  {!streamRef.current && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                      <div className="text-center text-white p-4">
                        <Camera className="h-12 w-12 mx-auto mb-2" />
                        <p className="text-sm">Presiona "Iniciar Cámara" para comenzar</p>
                        <p className="text-xs mt-2 opacity-75">Asegúrate de permitir el acceso a la cámara</p>
                      </div>
                    </div>
                  )}
                  
                  {/* Capture button overlay when camera is active */}
                  {streamRef.current && (
                    <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-10">
                      <Button
                        onClick={capturePhoto}
                        size="lg"
                        className="rounded-full h-20 w-20 bg-white text-black hover:bg-gray-100 shadow-xl border-4 border-gray-300 active:scale-95 transition-transform"
                      >
                        <Camera className="h-10 w-10" />
                      </Button>
                    </div>
                  )}
                  
                  {/* Camera guide overlay */}
                  {streamRef.current && (
                    <div className="absolute top-4 left-4 right-4">
                      <div className="bg-black/70 text-white p-2 rounded text-xs text-center">
                        Posiciona la boleta dentro del marco y presiona el botón para capturar
                      </div>
                    </div>
                  )}
                  
                  {/* Receipt frame guide */}
                  {streamRef.current && (
                    <div className="absolute inset-4 border-2 border-white border-dashed rounded-lg pointer-events-none opacity-50"></div>
                  )}
                </div>

                {/* Camera controls - Always visible */}
                <div className="space-y-3">
                  <div className="grid grid-cols-1 gap-2">
                    <Button 
                      onClick={startCamera} 
                      className="w-full h-12 text-lg"
                      disabled={!!streamRef.current}
                    >
                      <Camera className="h-5 w-5 mr-2" />
                      {streamRef.current ? 'Cámara Activa' : 'Iniciar Cámara'}
                    </Button>
                    
                    {streamRef.current && (
                      <>
                        <Button 
                          onClick={capturePhoto} 
                          className="w-full h-12 text-lg bg-green-600 hover:bg-green-700"
                        >
                          <Camera className="h-5 w-5 mr-2" />
                          Capturar Foto
                        </Button>
                        
                        {isMobile && (
                          <Button 
                            onClick={switchCamera} 
                            variant="outline"
                            className="w-full h-10"
                          >
                            <RotateCcw className="h-4 w-4 mr-2" />
                            Cambiar a Cámara {currentFacingMode === 'environment' ? 'Frontal' : 'Trasera'}
                          </Button>
                        )}
                      </>
                    )}
                    
                    <Button
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full h-12 text-lg"
                    >
                      <Upload className="h-5 w-5 mr-2" />
                      Subir desde Galería
                    </Button>
                    
                    {streamRef.current && (
                      <Button 
                        onClick={stopCamera} 
                        variant="outline"
                        className="w-full h-10"
                      >
                        <X className="h-4 w-4 mr-2" />
                        Cerrar Cámara
                      </Button>
                    )}
                  </div>
                  
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>

                {/* Tips */}
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                  <h4 className="font-medium text-sm mb-2">💡 Tips para mejores resultados:</h4>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Asegúrate de que la boleta esté bien iluminada</li>
                    <li>• Mantén la cámara estable y enfocada</li>
                    <li>• Incluye toda la información importante en la foto</li>
                    <li>• Evita sombras y reflejos en el papel</li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col gap-4">
                {/* Captured image preview */}
                <div className="flex-1 bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                  <img
                    src={capturedImage}
                    alt="Boleta capturada"
                    className="w-full h-full object-contain"
                  />
                </div>

                {/* Image controls */}
                <div className="flex gap-2">
                  {!extractedData ? (
                    <>
                      <Button
                        onClick={processImage}
                        disabled={isProcessing}
                        className="flex-1"
                      >
                        {isProcessing ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <Check className="h-4 w-4 mr-2" />
                        )}
                        {isProcessing ? 'Procesando...' : 'Extraer Datos'}
                      </Button>
                      <Button variant="outline" onClick={resetScanner}>
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Nueva Foto
                      </Button>
                    </>
                  ) : (
                    <Button variant="outline" onClick={resetScanner} className="flex-1">
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Nueva Boleta
                    </Button>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Data Extraction Results */}
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Datos Extraídos</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col">
            {isProcessing ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Analizando la boleta con IA...
                  </p>
                </div>
              </div>
            ) : extractedData && editableData ? (
              <div className="flex-1 flex flex-col gap-4">
                <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="flex items-center gap-2 mb-2">
                    <Check className="h-4 w-4 text-green-600" />
                    <span className="font-medium text-green-700 dark:text-green-300">Datos extraídos correctamente</span>
                  </div>
                  <p className="text-sm text-green-600 dark:text-green-400">
                    Revisa y edita los datos antes de guardar la transacción
                  </p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="amount">Monto</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={editableData.amount}
                      onChange={(e) => setEditableData({...editableData, amount: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Descripción</Label>
                    <Input
                      id="description"
                      value={editableData.description}
                      onChange={(e) => setEditableData({...editableData, description: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="date">Fecha</Label>
                    <Input
                      id="date"
                      type="date"
                      value={editableData.date}
                      onChange={(e) => setEditableData({...editableData, date: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="type">Tipo</Label>
                    <Select
                      value={editableData.type}
                      onValueChange={(value: 'income' | 'expense') => 
                        setEditableData({...editableData, type: value})
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="expense">Gasto</SelectItem>
                        <SelectItem value="income">Ingreso</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="category">Categoría</Label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar categoría" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.id.toString()}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {editableData.merchant && (
                    <div>
                      <Label>Comercio</Label>
                      <Input value={editableData.merchant} disabled />
                    </div>
                  )}

                  <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                    <p className="text-sm">
                      <strong>Confianza del escaneo:</strong> {Math.round(editableData.confidence * 100)}%
                    </p>
                    {editableData.confidence < 0.8 && (
                      <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                        ⚠️ Verifica los datos antes de guardar
                      </p>
                    )}
                  </div>
                </div>

                <div className="mt-auto space-y-3">
                  <Button
                    onClick={saveTransaction}
                    disabled={!selectedCategory || createTransactionMutation.isPending}
                    className="w-full h-12 text-lg bg-green-600 hover:bg-green-700"
                    size="lg"
                  >
                    {createTransactionMutation.isPending ? (
                      <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    ) : (
                      <Check className="h-5 w-5 mr-2" />
                    )}
                    Guardar Transacción
                  </Button>
                  <Button variant="outline" onClick={resetScanner} className="w-full">
                    <X className="h-4 w-4 mr-2" />
                    Escanear Nueva Boleta
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <Camera className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Toma una foto de tu boleta para comenzar</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
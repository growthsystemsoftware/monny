import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { getAuthHeaders } from "@/lib/auth";
import { Link } from "wouter";
import CategoryTransactionModal from "./CategoryTransactionModal";

interface ChartData {
  month: string;
  income: number;
  expenses: number;
}

interface CategoryData {
  name: string;
  amount: number;
  percentage: number;
  transactions: number;
  color: string;
}

export function IncomeExpenseChart() {
  const [period, setPeriod] = useState("6M");

  // Format currency function for Chilean Pesos
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const { data: chartData = [] } = useQuery<ChartData[]>({
    queryKey: ["/api/stats/chart", period],
    queryFn: async () => {
      const response = await fetch(`/api/stats/chart?period=${period}`, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch chart data");
      return response.json();
    },
  });

  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-card-foreground">Ingresos vs Gastos</CardTitle>
          <p className="text-sm text-muted-foreground">
            {period === "7D" ? "Últimos 7 días" :
             period === "1M" ? "Último mes" :
             period === "6M" ? "Últimos 6 meses" :
             "Último año"}
          </p>
        </div>
        <div className="flex space-x-1">
          {["7D", "1M", "6M", "1Y"].map((p) => (
            <Button 
              key={p}
              variant="outline" 
              size="sm" 
              onClick={() => setPeriod(p)}
              className={`text-xs ${
                period === p 
                  ? "bg-blue-50 dark:bg-blue-900/20 text-blue-600 border-blue-200 dark:border-blue-800" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {p === "7D" ? "7 días" : p === "1M" ? "1 mes" : p}
            </Button>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => formatCurrency(value)}
              />
              <Tooltip
                formatter={(value: number, name: string) => [
                  formatCurrency(value),
                  name === 'income' ? 'Ingresos' : 'Gastos'
                ]}
                labelFormatter={(label) => `${label}`}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                  color: 'hsl(var(--card-foreground))',
                }}
              />
              <Line
                type="monotone"
                dataKey="income"
                stroke="#059669"
                strokeWidth={2}
                dot={{ fill: '#059669', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
              <Line
                type="monotone"
                dataKey="expenses"
                stroke="#dc2626"
                strokeWidth={2}
                dot={{ fill: '#dc2626', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

export function CategoryChart() {
  const [selectedCategory, setSelectedCategory] = useState<{ name: string; color: string } | null>(null);

  // Format currency function for Chilean Pesos
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const { data: categoryData = [] } = useQuery<CategoryData[]>({
    queryKey: ["/api/stats/categories"],
    queryFn: async () => {
      const response = await fetch("/api/stats/categories", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch category data");
      return response.json();
    },
  });

  const handleCategoryClick = (categoryName: string, categoryColor: string) => {
    setSelectedCategory({ name: categoryName, color: categoryColor });
  };

  const handleCloseModal = () => {
    setSelectedCategory(null);
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-card-foreground">Gastos por Categoría</CardTitle>
        <Link href="/transactions">
          <Button variant="outline" size="sm" className="text-blue-600">
            Ver Todas
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        {categoryData.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No hay datos de gastos disponibles</p>
            <p className="text-sm text-muted-foreground mt-1">Añade algunas transacciones para ver el desglose de gastos</p>
          </div>
        ) : (
          <div className="space-y-4">
            {categoryData.map((category, index) => (
              <div key={index} className="space-y-2">
                <div 
                  className="flex items-center justify-between cursor-pointer hover:bg-muted/30 rounded-lg p-2 -mx-2 transition-colors"
                  onClick={() => handleCategoryClick(category.name, category.color)}
                >
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      <div 
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: category.color }}
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-card-foreground">{category.name}</p>
                      <p className="text-xs text-muted-foreground">{category.transactions} transacciones</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-card-foreground">{formatCurrency(category.amount)}</p>
                    <p className="text-xs text-muted-foreground">{category.percentage.toFixed(1)}%</p>
                  </div>
                </div>
                <Progress value={category.percentage} className="h-2" />
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* Category Transaction Modal */}
      {selectedCategory && (
        <CategoryTransactionModal
          isOpen={!!selectedCategory}
          onClose={handleCloseModal}
          categoryName={selectedCategory.name}
          categoryColor={selectedCategory.color}
        />
      )}
    </Card>
  );
}

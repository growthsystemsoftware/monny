import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getAuthHeaders } from "@/lib/auth";

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingTransaction?: {
    id: number;
    type: 'income' | 'expense';
    amount: string;
    description: string;
    categoryName?: string;
    date: string;
    notes?: string;
  } | null;
}

interface Category {
  id: number;
  name: string;
  icon: string;
  color: string;
}

export default function TransactionModal({ isOpen, onClose, editingTransaction }: TransactionModalProps) {
  const [formData, setFormData] = useState({
    type: "expense",
    amount: "",
    description: "",
    categoryId: "",
    date: new Date().toISOString().split('T')[0],
    notes: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    },
  });

  const initializedRef = useRef(false);

  // Populate form when editing a transaction
  useEffect(() => {
    if (editingTransaction && categories.length > 0 && !initializedRef.current) {
      const category = categories.find(cat => cat.name === editingTransaction.categoryName);
      setFormData({
        type: editingTransaction.type,
        amount: parseFloat(editingTransaction.amount).toString(),
        description: editingTransaction.description,
        categoryId: category?.id.toString() || "",
        date: new Date(editingTransaction.date).toISOString().split('T')[0],
        notes: editingTransaction.notes || "",
      });
      initializedRef.current = true;
    } else if (!editingTransaction && initializedRef.current) {
      setFormData({
        type: "expense",
        amount: "",
        description: "",
        categoryId: "",
        date: new Date().toISOString().split('T')[0],
        notes: "",
      });
      initializedRef.current = false;
    }
  }, [editingTransaction, categories]);

  // Reset initialization flag when modal closes
  useEffect(() => {
    if (!isOpen) {
      initializedRef.current = false;
    }
  }, [isOpen]);

  const createTransactionMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const method = editingTransaction ? "PUT" : "POST";
      const url = editingTransaction ? `/api/transactions/${editingTransaction.id}` : "/api/transactions";

      console.log("Frontend mutation:", {
        method,
        url,
        editingTransaction: editingTransaction?.id,
        data: {
          ...data,
          categoryId: parseInt(data.categoryId),
          date: data.date,
        }
      });

      const response = await apiRequest(url, method, {
        ...data,
        categoryId: parseInt(data.categoryId),
        date: data.date,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: editingTransaction ? "Transacción actualizada" : "Transacción agregada",
        description: editingTransaction ? "Tu transacción ha sido actualizada exitosamente." : "Tu transacción ha sido registrada exitosamente.",
      });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo procesar la transacción. Por favor intenta de nuevo.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setFormData({
      type: "expense",
      amount: "",
      description: "",
      categoryId: "",
      date: new Date().toISOString().split('T')[0],
      notes: "",
    });
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Enhanced validation with detailed logging
    console.log("Form data validation:", formData);
    
    if (!formData.amount || !formData.description || !formData.categoryId) {
      console.log("Validation failed:", {
        amount: !!formData.amount,
        description: !!formData.description,
        categoryId: !!formData.categoryId
      });
      
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos obligatorios.",
        variant: "destructive",
      });
      return;
    }

    // Validate amount is a positive number
    const amountNum = parseFloat(formData.amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      toast({
        title: "Monto inválido",
        description: "Por favor ingresa un monto válido mayor a 0.",
        variant: "destructive",
      });
      return;
    }

    createTransactionMutation.mutate(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="app-text">
            {editingTransaction ? "Editar Transacción" : "Agregar Nueva Transacción"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-sm font-medium app-text mb-2 block">Tipo de Transacción</Label>
            <RadioGroup
              value={formData.type}
              onValueChange={(value) => setFormData({ ...formData, type: value })}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="expense" id="expense" />
                <Label htmlFor="expense">Gasto</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="income" id="income" />
                <Label htmlFor="income">Ingreso</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <Label htmlFor="amount" className="text-sm font-medium app-text mb-2 block">
              Monto *
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="0.00"
                className="pl-8"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="description" className="text-sm font-medium app-text mb-2 block">
              Descripción *
            </Label>
            <Input
              id="description"
              placeholder="Descripción de la transacción"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              required
            />
          </div>

          <div>
            <Label htmlFor="category" className="text-sm font-medium app-text mb-2 block">
              Categoría *
            </Label>
            <Select
              value={formData.categoryId}
              onValueChange={(value) => setFormData({ ...formData, categoryId: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar una categoría" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="date" className="text-sm font-medium app-text mb-2 block">
              Fecha
            </Label>
            <Input
              id="date"
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="notes" className="text-sm font-medium app-text mb-2 block">
              Notas (Opcional)
            </Label>
            <Textarea
              id="notes"
              placeholder="Notas adicionales..."
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button type="button" variant="outline" className="flex-1" onClick={handleClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="flex-1" 
              disabled={createTransactionMutation.isPending}
            >
              {createTransactionMutation.isPending 
                ? (editingTransaction ? "Actualizando..." : "Agregando...") 
                : (editingTransaction ? "Actualizar Transacción" : "Agregar Transacción")
              }
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Download, TrendingUp, TrendingDown, DollarSign, PieChart } from "lucide-react";
import { getAuthHeaders } from "@/lib/auth";
import { IncomeExpenseChart, CategoryChart } from "@/components/Charts";
import { useState } from "react";

interface ReportData {
  totalIncome: number;
  totalExpenses: number;
  netSavings: number;
  goalContributions: number;
  incomeChange: number;
  expenseChange: number;
  savingsChange: number;
  topCategories: Array<{
    name: string;
    amount: number;
    percentage: number;
    transactions: number;
  }>;
  monthlyTrends: Array<{
    month: string;
    income: number;
    expenses: number;
    savings: number;
  }>;
}

export default function Reports() {
  const [selectedPeriod, setSelectedPeriod] = useState("6M");

  // Format currency function for Chilean Pesos
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const { data: reportData, isLoading } = useQuery<ReportData>({
    queryKey: ["/api/reports", selectedPeriod],
    queryFn: async () => {
      const response = await fetch(`/api/reports?period=${selectedPeriod}`, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch report data");
      return response.json();
    },
  });

  const handleExportPDF = () => {
    console.log("Exporting PDF report...");
  };

  const handleExportExcel = () => {
    console.log("Exporting Excel report...");
  };

  if (isLoading) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
          <div className="h-96 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">Reportes Financieros</h1>
          <p className="text-muted-foreground">Información detallada sobre tu salud financiera</p>
        </div>
        <div className="flex items-center space-x-4 mt-4 sm:mt-0">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1M">Último Mes</SelectItem>
              <SelectItem value="3M">Últimos 3 Meses</SelectItem>
              <SelectItem value="6M">Últimos 6 Meses</SelectItem>
              <SelectItem value="1Y">Último Año</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={handleExportPDF}>
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportExcel}>
              <Download className="h-4 w-4 mr-2" />
              Excel
            </Button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <Badge 
                variant="outline"
                className={`${
                  (reportData?.incomeChange || 0) >= 0 
                    ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800' 
                    : 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800'
                }`}
              >
                {(reportData?.incomeChange || 0) >= 0 ? '+' : ''}{reportData?.incomeChange?.toFixed(1) || 0}%
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Ingresos Totales</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(reportData?.totalIncome || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-red-50 dark:bg-red-900/20 rounded-lg flex items-center justify-center">
                <TrendingDown className="h-6 w-6 text-red-600" />
              </div>
              <Badge 
                variant="outline"
                className={`${
                  (reportData?.expenseChange || 0) <= 0 
                    ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800' 
                    : 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800'
                }`}
              >
                {(reportData?.expenseChange || 0) >= 0 ? '+' : ''}{reportData?.expenseChange?.toFixed(1) || 0}%
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Gastos Totales</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(reportData?.totalExpenses || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-blue-600" />
              </div>
              <Badge 
                variant="outline"
                className={`${
                  (reportData?.savingsChange || 0) >= 0 
                    ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800' 
                    : 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800'
                }`}
              >
                {(reportData?.savingsChange || 0) >= 0 ? '+' : ''}{reportData?.savingsChange?.toFixed(1) || 0}%
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Saldo Total</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(reportData?.netSavings || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-purple-50 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <Badge variant="outline" className="bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400 border-purple-200 dark:border-purple-800">
                Metas
              </Badge>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Dinero en Metas</h3>
            <p className="text-2xl font-semibold text-card-foreground">
              {formatCurrency(reportData?.goalContributions || 0)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <IncomeExpenseChart />
        <CategoryChart />
      </div>

      {/* Top Categories */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground flex items-center">
            <PieChart className="h-5 w-5 mr-2" />
            Principales Categorías de Gasto
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!reportData?.topCategories || reportData.topCategories.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No hay datos de gastos disponibles para este período</p>
            </div>
          ) : (
            <div className="space-y-4">
              {reportData.topCategories.map((category, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                      <span className="text-sm font-semibold text-blue-600">#{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-medium text-card-foreground">{category.name}</p>
                      <p className="text-sm text-muted-foreground">{category.transactions} transacciones</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-card-foreground">{formatCurrency(category.amount)}</p>
                    <p className="text-sm text-muted-foreground">{category.percentage.toFixed(1)}%</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

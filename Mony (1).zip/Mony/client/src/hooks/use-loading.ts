import { create } from 'zustand';

interface LoadingState {
  isLoading: boolean;
  message: string;
  setLoading: (loading: boolean, message?: string) => void;
}

export const useLoading = create<LoadingState>((set) => ({
  isLoading: false,
  message: 'Cargando...',
  setLoading: (loading: boolean, message = 'Cargando...') => 
    set({ isLoading: loading, message }),
}));
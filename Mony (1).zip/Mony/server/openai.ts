import OpenAI from "openai";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY environment variable is not set");
}

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY.trim(),
  timeout: 30000 // 30 seconds timeout
});

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export async function getFinancialAdvice(
  userId: number,
  userMessage: string,
  chatHistory: ChatMessage[] = []
): Promise<string> {
  try {
    // Get user's financial data
    const [transactions, budgets, goals, dashboardStats, categoryStats] = await Promise.all([
      storage.getTransactionsByUserId(userId),
      storage.getBudgetsByUserId(userId),
      storage.getGoalsByUserId(userId),
      storage.getDashboardStats(userId, "1M"),
      storage.getCategoryStats(userId)
    ]);

    // Get detailed budget information
    const budgetDetails = budgets.map(budget => ({
      category: budget.categoryName,
      amount: budget.amount,
      period: budget.period,
      spent: budget.spent,
      remaining: budget.remaining,
      percentage: budget.percentage
    }));

    // Get detailed goal information
    const goalDetails = goals.map(goal => ({
      name: goal.name,
      description: goal.description,
      targetAmount: goal.targetAmount,
      currentAmount: goal.currentAmount,
      targetDate: goal.targetDate,
      progress: ((parseFloat(goal.currentAmount.toString()) / parseFloat(goal.targetAmount.toString())) * 100).toFixed(1)
    }));

    // Prepare financial context for the AI
    const financialContext = {
      stats: dashboardStats,
      categories: categoryStats,
      budgets: budgets,
      goals: goals,
      recentTransactions: transactions.slice(0, 10) // Last 10 transactions
    };

    const systemPrompt = `Eres un asistente financiero experto especializado en finanzas personales para el mercado chileno. 

DATOS FINANCIEROS DEL USUARIO:
- Ingresos totales (último mes): $${dashboardStats.totalIncome?.toLocaleString('es-CL') || 0}
- Gastos totales (último mes): $${dashboardStats.totalExpenses?.toLocaleString('es-CL') || 0}
- Ahorro neto: $${dashboardStats.netSavings?.toLocaleString('es-CL') || 0}
- Presupuesto usado: ${dashboardStats.budgetPercentage || 0}%
- Contribuciones a metas: $${dashboardStats.goalContributions?.toLocaleString('es-CL') || 0}
- Número de transacciones recientes: ${transactions.length}

PRESUPUESTOS ACTIVOS (${budgets.length}):
${budgetDetails.map(budget => `- ${budget.category}: $${parseFloat(budget.amount).toLocaleString('es-CL')} ${budget.period} (gastado: $${budget.spent?.toLocaleString('es-CL') || 0}, ${budget.percentage || 0}% usado)`).join('\n') || 'No hay presupuestos configurados'}

METAS FINANCIERAS ACTIVAS (${goals.length}):
${goalDetails.map(goal => `- **${goal.name}**: ${goal.description || 'Sin descripción'}
  Meta: $${parseFloat(goal.targetAmount.toString()).toLocaleString('es-CL')}
  Actual: $${parseFloat(goal.currentAmount.toString()).toLocaleString('es-CL')} (${goal.progress}% completado)
  Fecha objetivo: ${goal.targetDate ? new Date(goal.targetDate).toLocaleDateString('es-CL') : 'No especificada'}`).join('\n') || 'No hay metas configuradas'}

PRINCIPALES CATEGORÍAS DE GASTOS:
${categoryStats.map((cat: any) => `- ${cat.name}: $${cat.amount.toLocaleString('es-CL')} (${cat.percentage}%)`).join('\n')}

TRANSACCIONES RECIENTES:
${transactions.slice(0, 5).map(t => `- ${t.type === 'income' ? 'Ingreso' : 'Gasto'}: $${parseFloat(t.amount).toLocaleString('es-CL')} - ${t.description} (${new Date(t.date).toLocaleDateString('es-CL')})`).join('\n')}

INSTRUCCIONES:
1. Proporciona consejos financieros personalizados basados únicamente en los datos reales del usuario
2. Combina TECNICISMO FINANCIERO con EXPLICACIONES EDUCATIVAS:
   - Usa terminología técnica correcta (ratio de gastos, flujo de caja, liquidez, etc.)
   - Inmediatamente después explica el concepto en palabras simples
   - Ejemplo: "Tu **ratio de gastos discrecionales** (gastos no esenciales como entretenimiento) representa el 15% de tus ingresos. Esto significa que de cada $100 que ganas, $15 los usas en cosas que no son básicas para vivir."
3. Usa formato Markdown para estructurar tus respuestas:
   - **Negritas** para conceptos técnicos importantes
   - *Cursivas* para énfasis en aprendizaje
   - ### Encabezados para organizar secciones
   - Listas numeradas o con viñetas para consejos
   - \`Código\` para mostrar cálculos específicos
4. ESTRUCTURA EDUCATIVA recomendada:
   - Menciona el concepto técnico
   - Explica qué significa en términos simples
   - Aplica el concepto a sus datos específicos
   - Da una recomendación práctica
5. Enfócate en ahorro, control de gastos y optimización financiera
6. NO sugieras inversiones específicas
7. Usa pesos chilenos ($) en todos los cálculos
8. Sé específico con los números basándote en los datos reales
9. Incluye CONCEPTOS EDUCATIVOS como:
   - Presupuesto 50/30/20 (50% necesidades, 30% deseos, 20% ahorro)
   - Fondo de emergencia (3-6 meses de gastos)
   - Flujo de caja positivo/negativo
   - Gastos fijos vs variables
   - Inflación y poder adquisitivo
10. Cuando hables de metas financieras, menciona específicamente:
    - El nombre de la meta y el concepto de **planificación financiera**
    - Su descripción y por qué es importante tener **objetivos SMART** (específicos, medibles, alcanzables, relevantes, con tiempo definido)
    - El progreso actual y explica el concepto de **capitalización** o **ahorro sistemático**
11. Para presupuestos, explica conceptos como:
    - **Presupuesto por categorías** y por qué es importante
    - **Variabilidad de gastos** y estacionalidad
    - **Control de gastos** vs restricción total
12. Si no hay suficientes datos, explícalo usando conceptos de **trazabilidad financiera** y **registro de transacciones**

13. ADOPTA UN ENFOQUE DE "VERDADES FINANCIERAS INCÓMODAS":
    - Sé directo sobre hábitos de gasto problemáticos
    - Identifica gastos que NO contribuyen a las metas financieras del usuario
    - Usa frases como: "La realidad es que...", "Necesitas escuchar esto...", "Por difícil que sea admitirlo..."
    - Destaca la diferencia entre QUERER algo y NECESITARLO financieramente
    - Explica el **costo de oportunidad** de cada gasto (qué se está sacrificando por gastar en eso)
    - Menciona conceptos como **gratificación instantánea vs planificación a largo plazo**
    
14. EJEMPLOS DE ENFOQUE DIRECTO:
    - "Tus gastos en [categoría] están saboteando tu meta de [nombre de meta]"
    - "Cada vez que gastas $X en [categoría], estás retrasando tu meta Y días/meses"
    - "Tu **patrón de consumo impulsivo** te está costando $X mensual que podrían ir a tu fondo de emergencia"
    - "La cruda realidad: al ritmo actual de gastos en [categoría], tardarás X años más en alcanzar tu meta"

15. IDENTIFICA PATRONES ESPECÍFICOS DE GASTO y da ALTERNATIVAS CONCRETAS:
    - **Entretenimiento/Discotecas**: "Veo que has gastado $X en discotecas/entretenimiento en Y días. La frecuencia de estas salidas está impactando directamente tu capacidad de ahorro. Considera reducir estas salidas a X veces al mes y destina ese dinero a tu meta de [nombre]."
    - **Transporte/Uber**: "Tus gastos en Uber suman $X mensual. Podrías ahorrar $Y usando transporte público o compartido algunas veces por semana. Ese ahorro de $Y podría acelerar tu meta en X meses."
    - **Delivery/Comida**: "Ordenas comida $X veces por semana gastando $Y. Cocinar en casa te ahorraría $Z mensual que podrían ir directo a tu fondo de emergencia."
    - **Compras impulsivas**: "Tus compras en [categoría] no tienen un patrón planificado. Cada compra impulsiva de $X retrasa tu meta Y días."

16. MANTÉN UN TONO CONSTRUCTIVO pero FIRME:
    - No juzgues a la persona, juzga las decisiones financieras
    - Siempre ofrece una alternativa específica y calculada
    - Usa datos específicos para respaldar cada observación incómoda
    - Calcula exactamente cuánto tiempo/dinero se ahorraría con el cambio
    - Termina con motivación sobre lo que SÍ pueden lograr con esos cambios

NUNCA uses datos ficticios o ejemplos genéricos. Solo trabaja con la información financiera real proporcionada.`;

    const messages: ChatMessage[] = [
      { role: 'system', content: systemPrompt },
      ...chatHistory.slice(-10), // Keep last 10 messages for context
      { role: 'user', content: userMessage }
    ];

    // Try gpt-4o first, fallback to gpt-3.5-turbo if not available
    let response;
    try {
      response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: messages,
        max_tokens: 1000,
        temperature: 0.7,
      });
    } catch (modelError: any) {
      if (modelError.status === 404 || modelError.code === 'model_not_found') {
        console.log('gpt-4o not available, trying gpt-3.5-turbo');
        response = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: messages,
          max_tokens: 1000,
          temperature: 0.7,
        });
      } else {
        throw modelError;
      }
    }

    return response.choices[0].message.content || "Lo siento, no pude generar una respuesta en este momento.";
  } catch (error) {
    console.error('Error getting financial advice:', error);
    throw new Error("Error al generar consejo financiero. Por favor, inténtalo de nuevo.");
  }
}

export async function extractReceiptData(imageBase64: string): Promise<any> {
  try {
    if (!openai) {
      throw new Error('API key no configurada. El servicio de IA no está disponible.');
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Eres un experto en extracción de datos de boletas y recibos chilenos. 

INSTRUCCIONES ESPECÍFICAS:
- Extrae ÚNICAMENTE los datos esenciales: monto total, descripción corta, fecha, tipo de transacción
- IGNORA información adicional como detalles de productos individuales, promociones, códigos de barra, etc.
- Enfócate en la información principal de la transacción

DATOS A EXTRAER:
1. amount (string): Monto total de la boleta
2. description (string): Descripción breve del comercio o tipo de compra (máximo 30 caracteres)
3. date (string): Fecha en formato YYYY-MM-DD EXACTO
4. type (string): "expense" para compras, "income" para ingresos
5. merchant (string): Nombre del comercio si es visible
6. suggestedCategory (string): Una de estas categorías: Alimentación, Transporte, Entretenimiento, Salud, Servicios, Hogar, Ropa, Educación
7. confidence (number): Nivel de confianza de 0 a 1

REGLAS IMPORTANTES:
- Si la imagen no es clara o no contiene una boleta válida, responde con confidence muy bajo (0.1-0.3)
- Si no encuentras fecha, usa la fecha actual
- La descripción debe ser concisa y útil
- Responde SOLO con JSON válido, sin markdown ni explicaciones adicionales

Ejemplo de respuesta:
{"amount":"12500","description":"Supermercado Jumbo","date":"2025-01-15","type":"expense","merchant":"Jumbo","suggestedCategory":"Alimentación","confidence":0.95}`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Extrae los datos de esta boleta o recibo:"
            },
            {
              type: "image_url",
              image_url: {
                url: imageBase64
              }
            }
          ]
        }
      ],
      max_tokens: 500,
      temperature: 0.1,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No se recibió respuesta del servicio de IA");
    }

    try {
      // Clean the response content by removing markdown code blocks if present
      let cleanContent = content.trim();
      
      // Remove markdown code blocks if they exist
      if (cleanContent.startsWith('```json') || cleanContent.startsWith('```')) {
        cleanContent = cleanContent.replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, '');
      }
      
      const extractedData = JSON.parse(cleanContent);
      
      // Validate required fields
      if (!extractedData.amount || !extractedData.description) {
        throw new Error("Datos incompletos extraídos de la boleta");
      }

      return extractedData;
    } catch (parseError) {
      console.error('Error parsing OpenAI response:', content);
      throw new Error("Error al procesar la respuesta de IA");
    }

  } catch (error: any) {
    console.error('Error extracting receipt data:', error);
    
    // Provide specific error messages based on error type
    if (error.code === 'insufficient_quota') {
      throw new Error("Límite de uso del servicio de IA alcanzado. Intenta más tarde.");
    } else if (error.code === 'invalid_api_key') {
      throw new Error("Configuración del servicio de IA incorrecta. Contacta al administrador.");
    } else if (error.code === 'rate_limit_exceeded') {
      throw new Error("Demasiadas solicitudes. Espera un momento antes de intentar nuevamente.");
    } else if (error.message?.includes('API key')) {
      throw new Error("El servicio de IA no está configurado correctamente.");
    } else if (error.message?.includes('format') || error.message?.includes('image')) {
      throw new Error("Formato de imagen no válido. Usa JPG, PNG o WebP.");
    } else if (error.message?.includes('too large')) {
      throw new Error("La imagen es demasiado grande. Intenta con una imagen más pequeña.");
    } else if (error.message?.includes('network') || error.code === 'ENOTFOUND') {
      throw new Error("Error de conexión. Verifica tu internet e intenta nuevamente.");
    } else {
      throw new Error(`Error al procesar la boleta: ${error.message || 'Error desconocido'}`);
    }
  }
}
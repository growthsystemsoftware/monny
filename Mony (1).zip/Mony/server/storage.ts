import { 
  users, categories, transactions, budgets, goals, chatHistory,
  type User, type InsertUser, type Category, type InsertCategory,
  type Transaction, type InsertTransaction, type Budget, type InsertBudget,
  type Goal, type InsertGoal, type ChatHistory, type InsertChatHistory
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

// Storage interface
interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  
  // Category methods
  getCategoriesByUserId(userId: number): Promise<Category[]>;
  createCategory(insertCategory: InsertCategory): Promise<Category>;
  updateCategory(id: number, insertCategory: InsertCategory, userId: number): Promise<Category>;
  deleteCategory(id: number, userId: number): Promise<void>;
  createDefaultCategories(userId: number): Promise<void>;
  
  // Transaction methods
  getTransactionsByUserId(userId: number): Promise<any[]>;
  getTransactionsByCategory(userId: number, categoryName: string): Promise<any[]>;
  createTransaction(insertTransaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, insertTransaction: InsertTransaction, userId: number): Promise<Transaction>;
  deleteTransaction(id: number, userId: number): Promise<void>;
  
  // Budget methods
  getBudgetsByUserId(userId: number): Promise<any[]>;
  createBudget(insertBudget: InsertBudget): Promise<Budget>;
  updateBudget(id: number, insertBudget: InsertBudget, userId: number): Promise<Budget>;
  deleteBudget(id: number, userId: number): Promise<void>;
  
  // Goal methods
  getGoalsByUserId(userId: number): Promise<Goal[]>;
  createGoal(insertGoal: InsertGoal): Promise<Goal>;
  updateGoal(id: number, insertGoal: InsertGoal, userId: number): Promise<Goal>;
  deleteGoal(id: number, userId: number): Promise<void>;
  contributeToGoal(goalId: number, amount: number, userId: number): Promise<{ goal: Goal; transaction: Transaction }>;
  
  // Chat history methods
  getChatHistory(userId: number): Promise<ChatHistory[]>;
  saveChatMessage(insertChatMessage: InsertChatHistory): Promise<ChatHistory>;
  clearChatHistory(userId: number): Promise<void>;
  
  // Stats methods
  getDashboardStats(userId: number, period?: string): Promise<any>;
  getChartData(userId: number, period?: string): Promise<any>;
  getCategoryStats(userId: number): Promise<any>;
  getBudgetAlerts(userId: number): Promise<any>;
  getReportData(userId: number, period: string): Promise<any>;
  populateDemoData(userId: number): Promise<void>;
  clearAllUserData(userId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getCategoriesByUserId(userId: number): Promise<Category[]> {
    return await db
      .select()
      .from(categories)
      .where(eq(categories.userId, userId));
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values(insertCategory)
      .returning();
    return category;
  }

  async updateCategory(id: number, insertCategory: InsertCategory, userId: number): Promise<Category> {
    const [category] = await db
      .update(categories)
      .set(insertCategory)
      .where(and(eq(categories.id, id), eq(categories.userId, userId)))
      .returning();
    
    if (!category) {
      throw new Error("Categoría no encontrada");
    }
    
    return category;
  }

  async deleteCategory(id: number, userId: number): Promise<void> {
    // Check if category has transactions
    const transactionCount = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(transactions)
      .where(and(eq(transactions.categoryId, id), eq(transactions.userId, userId)));

    if (Number(transactionCount[0]?.count || 0) > 0) {
      throw new Error("No se puede eliminar una categoría que tiene transacciones asociadas");
    }

    const result = await db
      .delete(categories)
      .where(and(eq(categories.id, id), eq(categories.userId, userId)))
      .returning();

    if (result.length === 0) {
      throw new Error("Categoría no encontrada");
    }
  }

  async createDefaultCategories(userId: number): Promise<void> {
    const defaultCategories = [
      { name: "Alimentación", icon: "Utensils", color: "#059669", isDefault: true, userId },
      { name: "Transporte", icon: "Car", color: "#dc2626", isDefault: true, userId },
      { name: "Entretenimiento", icon: "Film", color: "#7c3aed", isDefault: true, userId },
      { name: "Salud", icon: "Heart", color: "#ea580c", isDefault: true, userId },
      { name: "Educación", icon: "BookOpen", color: "#0891b2", isDefault: true, userId },
      { name: "Hogar", icon: "Home", color: "#65a30d", isDefault: true, userId },
      { name: "Ropa", icon: "Shirt", color: "#db2777", isDefault: true, userId },
      { name: "Salario", icon: "DollarSign", color: "#059669", isDefault: true, userId },
      { name: "Freelance", icon: "Briefcase", color: "#0891b2", isDefault: true, userId },
      { name: "Inversiones", icon: "TrendingUp", color: "#7c3aed", isDefault: true, userId },
    ];

    await db.insert(categories).values(defaultCategories);
  }

  async getTransactionsByUserId(userId: number): Promise<any[]> {
    return await db
      .select({
        id: transactions.id,
        description: transactions.description,
        amount: transactions.amount,
        type: transactions.type,
        date: transactions.date,
        notes: transactions.notes,
        categoryName: categories.name,
        categoryIcon: categories.icon,
        categoryColor: categories.color,
      })
      .from(transactions)
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.date));
  }

  async getTransactionsByCategory(userId: number, categoryName: string): Promise<any[]> {
    return await db
      .select({
        id: transactions.id,
        description: transactions.description,
        amount: transactions.amount,
        type: transactions.type,
        date: transactions.date,
        notes: transactions.notes,
        categoryName: categories.name,
        categoryIcon: categories.icon,
        categoryColor: categories.color,
      })
      .from(transactions)
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .where(
        and(
          eq(transactions.userId, userId),
          eq(categories.name, categoryName)
        )
      )
      .orderBy(desc(transactions.date));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async updateTransaction(id: number, insertTransaction: InsertTransaction, userId: number): Promise<Transaction> {
    console.log(`Updating transaction ${id} for user ${userId}:`, insertTransaction);
    const [transaction] = await db
      .update(transactions)
      .set(insertTransaction)
      .where(and(eq(transactions.id, id), eq(transactions.userId, userId)))
      .returning();
    
    if (!transaction) {
      throw new Error(`Transaction with id ${id} not found or not owned by user ${userId}`);
    }
    
    console.log(`Transaction updated successfully:`, transaction);
    return transaction;
  }

  async deleteTransaction(id: number, userId: number): Promise<void> {
    await db
      .delete(transactions)
      .where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
  }

  async getBudgetsByUserId(userId: number): Promise<any[]> {
    const budgetData = await db
      .select({
        id: budgets.id,
        amount: budgets.amount,
        period: budgets.period,
        alertThreshold: budgets.alertThreshold,
        startDate: budgets.startDate,
        endDate: budgets.endDate,
        categoryName: categories.name,
        categoryColor: categories.color,
      })
      .from(budgets)
      .leftJoin(categories, eq(budgets.categoryId, categories.id))
      .where(eq(budgets.userId, userId));

    // Calculate spent amounts for each budget
    const result = [];
    for (const budget of budgetData) {
      const spentData = await db
        .select({
          total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
        })
        .from(transactions)
        .innerJoin(categories, eq(transactions.categoryId, categories.id))
        .where(
          and(
            eq(transactions.userId, userId),
            eq(transactions.type, 'expense'),
            eq(categories.name, budget.categoryName),
            gte(transactions.date, budget.startDate),
            lte(transactions.date, budget.endDate)
          )
        );

      const spent = Number(spentData[0]?.total || 0);
      const budgetAmount = Number(budget.amount);
      const remaining = budgetAmount - spent;
      const percentage = budgetAmount > 0 ? (spent / budgetAmount) * 100 : 0;
      const isOverBudget = spent > budgetAmount;
      
      const now = new Date();
      const endDate = new Date(budget.endDate);
      const daysLeft = Math.max(0, Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

      result.push({
        ...budget,
        spent,
        remaining,
        percentage,
        isOverBudget,
        daysLeft,
      });
    }

    return result;
  }

  async createBudget(insertBudget: InsertBudget): Promise<Budget> {
    const [budget] = await db
      .insert(budgets)
      .values(insertBudget)
      .returning();
    return budget;
  }

  async updateBudget(id: number, insertBudget: InsertBudget, userId: number): Promise<Budget> {
    const [budget] = await db
      .update(budgets)
      .set(insertBudget)
      .where(and(eq(budgets.id, id), eq(budgets.userId, userId)))
      .returning();
    return budget;
  }

  async deleteBudget(id: number, userId: number): Promise<void> {
    await db
      .delete(budgets)
      .where(and(eq(budgets.id, id), eq(budgets.userId, userId)));
  }

  async getGoalsByUserId(userId: number): Promise<Goal[]> {
    return await db
      .select()
      .from(goals)
      .where(eq(goals.userId, userId))
      .orderBy(desc(goals.createdAt));
  }

  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    const [goal] = await db
      .insert(goals)
      .values(insertGoal)
      .returning();
    return goal;
  }

  async updateGoal(id: number, insertGoal: InsertGoal, userId: number): Promise<Goal> {
    const [goal] = await db
      .update(goals)
      .set(insertGoal)
      .where(and(eq(goals.id, id), eq(goals.userId, userId)))
      .returning();
    return goal;
  }

  async deleteGoal(id: number, userId: number): Promise<void> {
    const result = await db
      .delete(goals)
      .where(and(eq(goals.id, id), eq(goals.userId, userId)))
      .returning();

    if (result.length === 0) {
      throw new Error("Meta no encontrada");
    }
  }

  async contributeToGoal(goalId: number, amount: number, userId: number): Promise<{ goal: Goal; transaction: Transaction }> {
    // Get the goal and verify ownership
    const [existingGoal] = await db
      .select()
      .from(goals)
      .where(and(eq(goals.id, goalId), eq(goals.userId, userId)));

    if (!existingGoal) {
      throw new Error("Meta no encontrada");
    }

    // Update the goal's current amount
    const newCurrentAmount = parseFloat(existingGoal.currentAmount) + amount;
    const [updatedGoal] = await db
      .update(goals)
      .set({ currentAmount: newCurrentAmount.toString() })
      .where(eq(goals.id, goalId))
      .returning();

    // Find or create "Aporte a Metas" category
    let contributionCategory = await db
      .select()
      .from(categories)
      .where(and(eq(categories.userId, userId), eq(categories.name, "Aporte a Metas")))
      .limit(1);

    if (contributionCategory.length === 0) {
      const [newCategory] = await db
        .insert(categories)
        .values({
          userId,
          name: "Aporte a Metas",
          icon: "🎯",
          color: "#10B981"
        })
        .returning();
      contributionCategory = [newCategory];
    }

    // Create expense transaction for the contribution
    const [transaction] = await db
      .insert(transactions)
      .values({
        userId,
        categoryId: contributionCategory[0].id,
        type: "expense",
        amount: amount.toString(),
        description: `Aporte a meta: ${existingGoal.name}`,
        date: new Date(),
        notes: `Contribución a la meta financiera`
      })
      .returning();

    return { goal: updatedGoal, transaction };
  }

  async getDashboardStats(userId: number, period: string = "1M"): Promise<any> {
    const now = new Date();
    let currentStart: Date, currentEnd: Date, previousStart: Date, previousEnd: Date;

    // Calculate date ranges based on period
    switch (period) {
      case "7D":
        currentEnd = new Date(now);
        currentStart = new Date(now);
        currentStart.setDate(now.getDate() - 6);
        previousEnd = new Date(currentStart);
        previousEnd.setDate(previousEnd.getDate() - 1);
        previousStart = new Date(previousEnd);
        previousStart.setDate(previousStart.getDate() - 6);
        break;
      case "6M":
        currentStart = new Date(now.getFullYear(), now.getMonth() - 5, 1);
        currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        previousStart = new Date(now.getFullYear(), now.getMonth() - 11, 1);
        previousEnd = new Date(now.getFullYear(), now.getMonth() - 5, 0);
        break;
      case "1Y":
        currentStart = new Date(now.getFullYear() - 1, now.getMonth(), 1);
        currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        previousStart = new Date(now.getFullYear() - 2, now.getMonth(), 1);
        previousEnd = new Date(now.getFullYear() - 1, now.getMonth(), 0);
        break;
      default: // "1M"
        currentEnd = new Date(now);
        currentEnd.setHours(23, 59, 59, 999); // Fin del día actual
        currentStart = new Date(now);
        currentStart.setDate(now.getDate() - 29); // Últimos 30 días
        currentStart.setHours(0, 0, 0, 0); // Inicio del día
        previousEnd = new Date(currentStart);
        previousEnd.setDate(previousEnd.getDate() - 1);
        previousEnd.setHours(23, 59, 59, 999);
        previousStart = new Date(previousEnd);
        previousStart.setDate(previousStart.getDate() - 29);
        previousStart.setHours(0, 0, 0, 0);
    }

    // Get current period data
    const [currentIncomeData, currentExpenseData] = await Promise.all([
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'income'),
          gte(transactions.date, currentStart),
          lte(transactions.date, currentEnd)
        )
      ),
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'expense'),
          gte(transactions.date, currentStart),
          lte(transactions.date, currentEnd)
        )
      )
    ]);

    // Get historical (all-time) data for total balance
    const [historicalIncomeData, historicalExpenseData] = await Promise.all([
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'income')
        )
      ),
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'expense')
        )
      )
    ]);

    // Get previous period data for comparison
    const [previousIncomeData, previousExpenseData] = await Promise.all([
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'income'),
          gte(transactions.date, previousStart),
          lte(transactions.date, previousEnd)
        )
      ),
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'expense'),
          gte(transactions.date, previousStart),
          lte(transactions.date, previousEnd)
        )
      )
    ]);

    // Get budget data
    const budgetData = await db
      .select({
        total: sql<number>`COALESCE(SUM(CAST(${budgets.amount} AS DECIMAL)), 0)`,
      })
      .from(budgets)
      .where(eq(budgets.userId, userId));

    // Calculate totals
    const currentIncome = Number(currentIncomeData[0]?.total || 0);
    const currentExpenses = Number(currentExpenseData[0]?.total || 0);
    const previousIncome = Number(previousIncomeData[0]?.total || 0);
    const previousExpenses = Number(previousExpenseData[0]?.total || 0);
    
    // Calculate historical totals for the "Saldo Total"
    const historicalIncome = Number(historicalIncomeData[0]?.total || 0);
    const historicalExpenses = Number(historicalExpenseData[0]?.total || 0);
    const historicalBalance = historicalIncome - historicalExpenses;

    const currentSavings = currentIncome - currentExpenses;
    const previousSavings = previousIncome - previousExpenses;

    // Calculate money used for goals
    const goalContributionsData = await db
      .select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .innerJoin(categories, eq(transactions.categoryId, categories.id))
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'expense'),
          eq(categories.name, 'Aporte a Metas'),
          gte(transactions.date, currentStart),
          lte(transactions.date, currentEnd)
        )
      );

    const goalContributions = Number(goalContributionsData[0]?.total || 0);

    const totalBudget = Number(budgetData[0]?.total || 0);
    const budgetUsed = currentExpenses;
    const budgetPercentage = totalBudget > 0 ? (budgetUsed / totalBudget) * 100 : 0;

    // Calculate percentage changes
    const incomeChange = previousIncome > 0 ? ((currentIncome - previousIncome) / previousIncome) * 100 : 0;
    const expenseChange = previousExpenses > 0 ? ((currentExpenses - previousExpenses) / previousExpenses) * 100 : 0;
    // For savings change, compare current period savings since historical balance doesn't change period to period
    const savingsChange = previousSavings !== 0 ? ((currentSavings - previousSavings) / Math.abs(previousSavings)) * 100 : 0;
    const budgetChange = previousExpenses > 0 ? ((currentExpenses - previousExpenses) / previousExpenses) * 100 : 0;

    return {
      totalIncome: currentIncome,
      totalExpenses: currentExpenses,
      netSavings: historicalBalance, // Use historical balance for "Saldo Total"
      budgetUsed,
      totalBudget,
      budgetPercentage: Math.round(budgetPercentage),
      goalContributions,
      incomeChange: Math.round(incomeChange * 100) / 100,
      expenseChange: Math.round(expenseChange * 100) / 100,
      savingsChange: Math.round(savingsChange * 100) / 100,
      budgetChange: Math.round(budgetChange * 100) / 100,
    };
  }

  async getChartData(userId: number, period: string = "6M"): Promise<any> {
    const now = new Date();
    const results = [];
    
    switch (period) {
      case "7D":
        // Last 7 days
        for (let i = 6; i >= 0; i--) {
          const targetDate = new Date(now);
          targetDate.setDate(now.getDate() - i);
          const start = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate());
          const end = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate(), 23, 59, 59);
          
          const [incomeData, expenseData] = await Promise.all([
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'income'),
                gte(transactions.date, start),
                lte(transactions.date, end)
              )
            ),
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'expense'),
                gte(transactions.date, start),
                lte(transactions.date, end)
              )
            )
          ]);

          results.push({
            month: targetDate.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric' }),
            income: Number(incomeData[0]?.total || 0),
            expenses: Number(expenseData[0]?.total || 0),
          });
        }
        break;
      case "1M":
        // Last 30 days - show every 3rd day to avoid overcrowding, from oldest to newest
        for (let i = 29; i >= 0; i -= 3) {
          const startDate = new Date(now);
          startDate.setDate(now.getDate() - i);
          startDate.setHours(0, 0, 0, 0);
          
          const endDate = new Date(startDate);
          endDate.setHours(23, 59, 59, 999);
          
          const [incomeData, expenseData] = await Promise.all([
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'income'),
                gte(transactions.date, startDate),
                lte(transactions.date, endDate)
              )
            ),
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'expense'),
                gte(transactions.date, startDate),
                lte(transactions.date, endDate)
              )
            )
          ]);

          results.push({
            month: startDate.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }),
            income: Number(incomeData[0]?.total || 0),
            expenses: Number(expenseData[0]?.total || 0),
          });
        }
        
        // Add today as the final point
        const todayStart = new Date(now);
        todayStart.setHours(0, 0, 0, 0);
        const todayEnd = new Date(now);
        todayEnd.setHours(23, 59, 59, 999);
        
        const [todayIncomeData, todayExpenseData] = await Promise.all([
          db.select({
            total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.userId, userId),
              eq(transactions.type, 'income'),
              gte(transactions.date, todayStart),
              lte(transactions.date, todayEnd)
            )
          ),
          db.select({
            total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.userId, userId),
              eq(transactions.type, 'expense'),
              gte(transactions.date, todayStart),
              lte(transactions.date, todayEnd)
            )
          )
        ]);

        results.push({
          month: now.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }),
          income: Number(todayIncomeData[0]?.total || 0),
          expenses: Number(todayExpenseData[0]?.total || 0),
        });
        break;
      case "1Y":
        // Last 12 months
        for (let i = 11; i >= 0; i--) {
          const startDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
          const endDate = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
          
          const [incomeData, expenseData] = await Promise.all([
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'income'),
                gte(transactions.date, startDate),
                lte(transactions.date, endDate)
              )
            ),
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'expense'),
                gte(transactions.date, startDate),
                lte(transactions.date, endDate)
              )
            )
          ]);

          results.push({
            month: startDate.toLocaleDateString('es-ES', { month: 'short', year: 'numeric' }),
            income: Number(incomeData[0]?.total || 0),
            expenses: Number(expenseData[0]?.total || 0),
          });
        }
        break;
      default: // "6M"
        // Last 6 months
        for (let i = 5; i >= 0; i--) {
          const startDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
          const endDate = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
          
          const [incomeData, expenseData] = await Promise.all([
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'income'),
                gte(transactions.date, startDate),
                lte(transactions.date, endDate)
              )
            ),
            db.select({
              total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
            })
            .from(transactions)
            .where(
              and(
                eq(transactions.userId, userId),
                eq(transactions.type, 'expense'),
                gte(transactions.date, startDate),
                lte(transactions.date, endDate)
              )
            )
          ]);

          results.push({
            month: startDate.toLocaleDateString('es-ES', { month: 'short', year: 'numeric' }),
            income: Number(incomeData[0]?.total || 0),
            expenses: Number(expenseData[0]?.total || 0),
          });
        }
    }

    return results;
  }

  async getCategoryStats(userId: number): Promise<any> {
    const categoryData = await db
      .select({
        categoryName: categories.name,
        categoryColor: categories.color,
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
        count: sql<number>`COUNT(${transactions.id})`,
      })
      .from(transactions)
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'expense')
        )
      )
      .groupBy(categories.name, categories.color)
      .orderBy(sql`SUM(CAST(${transactions.amount} AS DECIMAL)) DESC`)
      .limit(5);

    const totalExpenses = categoryData.reduce((sum, cat) => sum + Number(cat.total), 0);

    return categoryData.map(cat => ({
      name: cat.categoryName,
      amount: Number(cat.total),
      percentage: totalExpenses > 0 ? (Number(cat.total) / totalExpenses) * 100 : 0,
      transactions: Number(cat.count),
      color: cat.categoryColor,
    }));
  }

  async getBudgetAlerts(userId: number): Promise<any> {
    const budgets = await this.getBudgetsByUserId(userId);
    return budgets.filter(budget => 
      budget.percentage >= budget.alertThreshold || budget.isOverBudget
    );
  }

  async getReportData(userId: number, period: string): Promise<any> {
    const now = new Date();
    let currentStart: Date, currentEnd: Date;

    // Use the same date calculation logic as getDashboardStats
    switch (period) {
      case '1M':
      case '1month':
        currentEnd = new Date(now);
        currentEnd.setHours(23, 59, 59, 999); // Fin del día actual
        currentStart = new Date(now);
        currentStart.setDate(now.getDate() - 29); // Últimos 30 días
        currentStart.setHours(0, 0, 0, 0); // Inicio del día
        break;
      case '3M':
      case '3months':
        currentStart = new Date(now.getFullYear(), now.getMonth() - 2, 1);
        currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
      case '6M':
      case '6months':
        currentStart = new Date(now.getFullYear(), now.getMonth() - 5, 1);
        currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
      case '1Y':
      case '1year':
        currentStart = new Date(now.getFullYear() - 1, now.getMonth(), 1);
        currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
      case '7D':
        currentEnd = new Date(now);
        currentStart = new Date(now);
        currentStart.setDate(now.getDate() - 6);
        break;
      default: // Default to 6 months
        currentStart = new Date(now.getFullYear(), now.getMonth() - 5, 1);
        currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    }

    const [incomeData, expenseData] = await Promise.all([
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'income'),
          gte(transactions.date, currentStart),
          lte(transactions.date, currentEnd)
        )
      ),
      db.select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'expense'),
          gte(transactions.date, currentStart),
          lte(transactions.date, currentEnd)
        )
      )
    ]);

    // Calculate money used for goals
    const goalContributionsData = await db
      .select({
        total: sql<number>`COALESCE(SUM(CAST(${transactions.amount} AS DECIMAL)), 0)`,
      })
      .from(transactions)
      .innerJoin(categories, eq(transactions.categoryId, categories.id))
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, 'expense'),
          eq(categories.name, 'Aporte a Metas'),
          gte(transactions.date, currentStart),
          lte(transactions.date, currentEnd)
        )
      );

    const goalContributions = Number(goalContributionsData[0]?.total || 0);

    const totalIncome = Number(incomeData[0]?.total || 0);
    const totalExpenses = Number(expenseData[0]?.total || 0);
    const netSavings = totalIncome - totalExpenses;

    const topCategories = await this.getCategoryStats(userId);

    return {
      totalIncome,
      totalExpenses,
      netSavings,
      goalContributions,
      incomeChange: 12.5,
      expenseChange: 8.3,
      savingsChange: 15.2,
      topCategories: topCategories.slice(0, 5),
      monthlyTrends: [],
    };
  }

  async populateDemoData(userId: number): Promise<void> {
    // Get user categories
    const userCategories = await this.getCategoriesByUserId(userId);
    if (userCategories.length === 0) return;

    // Create demo transactions for the last 12 months with realistic Chilean amounts
    const demoTransactions = [
      // Ingresos (típicos para Chile) - 2024
      { type: 'income', amount: '1200000', description: 'Salario Diciembre', categoryName: 'Salario', date: new Date('2024-12-01') },
      { type: 'income', amount: '1200000', description: 'Salario Noviembre', categoryName: 'Salario', date: new Date('2024-11-01') },
      { type: 'income', amount: '1200000', description: 'Salario Octubre', categoryName: 'Salario', date: new Date('2024-10-01') },
      { type: 'income', amount: '1200000', description: 'Salario Septiembre', categoryName: 'Salario', date: new Date('2024-09-01') },
      { type: 'income', amount: '1200000', description: 'Salario Agosto', categoryName: 'Salario', date: new Date('2024-08-01') },
      { type: 'income', amount: '1200000', description: 'Salario Julio', categoryName: 'Salario', date: new Date('2024-07-01') },
      { type: 'income', amount: '1200000', description: 'Salario Junio', categoryName: 'Salario', date: new Date('2024-06-01') },
      { type: 'income', amount: '1200000', description: 'Salario Mayo', categoryName: 'Salario', date: new Date('2024-05-01') },
      { type: 'income', amount: '1200000', description: 'Salario Abril', categoryName: 'Salario', date: new Date('2024-04-01') },
      { type: 'income', amount: '1200000', description: 'Salario Marzo', categoryName: 'Salario', date: new Date('2024-03-01') },
      { type: 'income', amount: '1200000', description: 'Salario Febrero', categoryName: 'Salario', date: new Date('2024-02-01') },
      { type: 'income', amount: '1200000', description: 'Salario Enero', categoryName: 'Salario', date: new Date('2024-01-01') },
      { type: 'income', amount: '250000', description: 'Proyecto Freelance', categoryName: 'Freelance', date: new Date('2024-12-15') },
      { type: 'income', amount: '180000', description: 'Bono Navidad', categoryName: 'Salario', date: new Date('2024-12-20') },
      { type: 'income', amount: '200000', description: 'Proyecto Web', categoryName: 'Freelance', date: new Date('2024-09-10') },
      { type: 'income', amount: '300000', description: 'Bono Fiestas Patrias', categoryName: 'Salario', date: new Date('2024-09-18') },
      { type: 'income', amount: '150000', description: 'Venta Artículos', categoryName: 'Freelance', date: new Date('2024-06-20') },
      
      // Gastos históricos (típicos para Chile) - Todo el año 2024
      // Diciembre 2024
      { type: 'expense', amount: '180000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-12-05') },
      { type: 'expense', amount: '85000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-12-10') },
      { type: 'expense', amount: '45000', description: 'Cena Restaurante', categoryName: 'Entretenimiento', date: new Date('2024-12-12') },
      { type: 'expense', amount: '35000', description: 'Consulta Médica', categoryName: 'Salud', date: new Date('2024-12-08') },
      { type: 'expense', amount: '120000', description: 'Curso Online', categoryName: 'Educación', date: new Date('2024-12-18') },
      { type: 'expense', amount: '95000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-12-25') },
      { type: 'expense', amount: '65000', description: 'Ropa Nueva', categoryName: 'Ropa', date: new Date('2024-12-22') },
      { type: 'expense', amount: '220000', description: 'Compras Navideñas', categoryName: 'Alimentación', date: new Date('2024-12-23') },
      { type: 'expense', amount: '25000', description: 'Cine', categoryName: 'Entretenimiento', date: new Date('2024-12-28') },
      { type: 'expense', amount: '150000', description: 'Mantenimiento Auto', categoryName: 'Transporte', date: new Date('2024-12-30') },
      
      // Noviembre 2024
      { type: 'expense', amount: '175000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-11-05') },
      { type: 'expense', amount: '80000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-11-08') },
      { type: 'expense', amount: '55000', description: 'Restaurante', categoryName: 'Entretenimiento', date: new Date('2024-11-15') },
      { type: 'expense', amount: '90000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-11-20') },
      { type: 'expense', amount: '40000', description: 'Farmacia', categoryName: 'Salud', date: new Date('2024-11-12') },
      
      // Octubre 2024
      { type: 'expense', amount: '170000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-10-05') },
      { type: 'expense', amount: '75000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-10-10') },
      { type: 'expense', amount: '30000', description: 'Teatro', categoryName: 'Entretenimiento', date: new Date('2024-10-20') },
      { type: 'expense', amount: '85000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-10-25') },
      { type: 'expense', amount: '120000', description: 'Zapatillas', categoryName: 'Ropa', date: new Date('2024-10-15') },
      
      // Septiembre 2024
      { type: 'expense', amount: '200000', description: 'Asado Fiestas Patrias', categoryName: 'Alimentación', date: new Date('2024-09-17') },
      { type: 'expense', amount: '90000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-09-05') },
      { type: 'expense', amount: '60000', description: 'Empanadas', categoryName: 'Alimentación', date: new Date('2024-09-18') },
      { type: 'expense', amount: '80000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-09-22') },
      { type: 'expense', amount: '45000', description: 'Cueca y Celebración', categoryName: 'Entretenimiento', date: new Date('2024-09-19') },
      
      // Agosto 2024
      { type: 'expense', amount: '165000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-08-05') },
      { type: 'expense', amount: '85000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-08-08') },
      { type: 'expense', amount: '110000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-08-20') },
      { type: 'expense', amount: '75000', description: 'Cena Fin de Semana', categoryName: 'Entretenimiento', date: new Date('2024-08-15') },
      { type: 'expense', amount: '50000', description: 'Vitaminas', categoryName: 'Salud', date: new Date('2024-08-12') },
      
      // Julio 2024
      { type: 'expense', amount: '160000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-07-05') },
      { type: 'expense', amount: '95000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-07-08') },
      { type: 'expense', amount: '120000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-07-20') },
      { type: 'expense', amount: '80000', description: 'Cine y Entretenimiento', categoryName: 'Entretenimiento', date: new Date('2024-07-15') },
      { type: 'expense', amount: '200000', description: 'Vacaciones Invierno', categoryName: 'Entretenimiento', date: new Date('2024-07-25') },
      
      // Junio 2024
      { type: 'expense', amount: '155000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-06-05') },
      { type: 'expense', amount: '80000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-06-08') },
      { type: 'expense', amount: '100000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-06-20') },
      { type: 'expense', amount: '45000', description: 'Almuerzo Domingo', categoryName: 'Entretenimiento', date: new Date('2024-06-15') },
      { type: 'expense', amount: '70000', description: 'Ropa Invierno', categoryName: 'Ropa', date: new Date('2024-06-12') },
      
      // Mayo 2024
      { type: 'expense', amount: '150000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-05-05') },
      { type: 'expense', amount: '75000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-05-08') },
      { type: 'expense', amount: '90000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-05-20') },
      { type: 'expense', amount: '60000', description: 'Día de la Madre', categoryName: 'Entretenimiento', date: new Date('2024-05-12') },
      { type: 'expense', amount: '35000', description: 'Medicamentos', categoryName: 'Salud', date: new Date('2024-05-15') },
      
      // Abril 2024
      { type: 'expense', amount: '145000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-04-05') },
      { type: 'expense', amount: '70000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-04-08') },
      { type: 'expense', amount: '85000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-04-20') },
      { type: 'expense', amount: '40000', description: 'Cine', categoryName: 'Entretenimiento', date: new Date('2024-04-15') },
      { type: 'expense', amount: '95000', description: 'Chaqueta Otoño', categoryName: 'Ropa', date: new Date('2024-04-12') },
      
      // Marzo 2024
      { type: 'expense', amount: '140000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-03-05') },
      { type: 'expense', amount: '68000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-03-08') },
      { type: 'expense', amount: '80000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-03-20') },
      { type: 'expense', amount: '55000', description: 'Restaurante', categoryName: 'Entretenimiento', date: new Date('2024-03-15') },
      { type: 'expense', amount: '120000', description: 'Útiles Escolares', categoryName: 'Educación', date: new Date('2024-03-01') },
      
      // Febrero 2024
      { type: 'expense', amount: '135000', description: 'Supermercado Mensual', categoryName: 'Alimentación', date: new Date('2024-02-05') },
      { type: 'expense', amount: '65000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-02-08') },
      { type: 'expense', amount: '75000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-02-20') },
      { type: 'expense', amount: '85000', description: 'Día del Amor', categoryName: 'Entretenimiento', date: new Date('2024-02-14') },
      { type: 'expense', amount: '100000', description: 'Ropa Verano', categoryName: 'Ropa', date: new Date('2024-02-10') },
      
      // Enero 2024  
      { type: 'expense', amount: '200000', description: 'Compras Año Nuevo', categoryName: 'Alimentación', date: new Date('2024-01-02') },
      { type: 'expense', amount: '90000', description: 'Gasolina', categoryName: 'Transporte', date: new Date('2024-01-08') },
      { type: 'expense', amount: '110000', description: 'Cuenta Luz', categoryName: 'Hogar', date: new Date('2024-01-20') },
      { type: 'expense', amount: '150000', description: 'Vacaciones Verano', categoryName: 'Entretenimiento', date: new Date('2024-01-15') },
      { type: 'expense', amount: '80000', description: 'Exámenes Médicos', categoryName: 'Salud', date: new Date('2024-01-25') },
      
      // Más gastos típicos chilenos
      { type: 'expense', amount: '120000', description: 'Arriendo', categoryName: 'Hogar', date: new Date('2024-12-01') },
      { type: 'expense', amount: '45000', description: 'Internet y Cable', categoryName: 'Hogar', date: new Date('2024-12-15') },
      { type: 'expense', amount: '35000', description: 'Celular', categoryName: 'Tecnología', date: new Date('2024-12-05') },
      { type: 'expense', amount: '80000', description: 'Farmacia', categoryName: 'Salud', date: new Date('2024-12-20') },
      { type: 'expense', amount: '60000', description: 'Peluquería', categoryName: 'Cuidado Personal', date: new Date('2024-12-14') },
      { type: 'expense', amount: '15000', description: 'Café Diario', categoryName: 'Alimentación', date: new Date('2024-12-11') },
      { type: 'expense', amount: '90000', description: 'Zapatillas', categoryName: 'Ropa', date: new Date('2024-12-16') },
      { type: 'expense', amount: '40000', description: 'Uber/Taxi', categoryName: 'Transporte', date: new Date('2024-12-19') },
    ];

    for (const txn of demoTransactions) {
      const category = userCategories.find(cat => cat.name === txn.categoryName);
      if (category) {
        await this.createTransaction({
          userId,
          categoryId: category.id,
          type: txn.type as 'income' | 'expense',
          amount: txn.amount,
          description: txn.description,
          date: txn.date,
          notes: 'Transacción de demostración',
        });
      }
    }

    // Create demo budgets with realistic Chilean amounts
    const demoBudgets = [
      { categoryName: 'Alimentación', amount: '400000', period: 'monthly', alertThreshold: 80 },
      { categoryName: 'Transporte', amount: '200000', period: 'monthly', alertThreshold: 75 },
      { categoryName: 'Entretenimiento', amount: '100000', period: 'monthly', alertThreshold: 85 },
      { categoryName: 'Salud', amount: '80000', period: 'monthly', alertThreshold: 90 },
    ];

    const now = new Date();
    const startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    const endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    for (const budget of demoBudgets) {
      const category = userCategories.find(cat => cat.name === budget.categoryName);
      if (category) {
        await this.createBudget({
          userId,
          categoryId: category.id,
          amount: budget.amount,
          period: budget.period,
          alertThreshold: budget.alertThreshold,
          startDate,
          endDate,
        });
      }
    }

    // Create demo goals with realistic Chilean amounts
    const demoGoals = [
      {
        name: 'Fondo de Emergencia',
        targetAmount: '3000000',
        currentAmount: '1200000',
        description: 'Ahorrar para emergencias inesperadas',
        targetDate: new Date('2025-12-31'),
      },
      {
        name: 'Vacaciones de Verano',
        targetAmount: '1500000',
        currentAmount: '450000',
        description: 'Viaje familiar a la playa',
        targetDate: new Date('2025-07-15'),
      },
      {
        name: 'Auto Nuevo',
        targetAmount: '12000000',
        currentAmount: '2800000',
        description: 'Pie para auto nuevo',
        targetDate: new Date('2026-03-15'),
      },
    ];

    for (const goal of demoGoals) {
      await this.createGoal({
        userId,
        name: goal.name,
        targetAmount: goal.targetAmount,
        currentAmount: goal.currentAmount,
        description: goal.description,
        targetDate: goal.targetDate,
      });
    }
  }

  async clearAllUserData(userId: number): Promise<void> {
    // Delete all user's transactions
    await db
      .delete(transactions)
      .where(eq(transactions.userId, userId));

    // Delete all user's budgets
    await db
      .delete(budgets)
      .where(eq(budgets.userId, userId));

    // Delete all user's goals
    await db
      .delete(goals)
      .where(eq(goals.userId, userId));

    // Delete all user's custom categories (keep default ones)
    await db
      .delete(categories)
      .where(and(eq(categories.userId, userId), eq(categories.isDefault, false)));
  }

  // Chat history methods
  async getChatHistory(userId: number): Promise<ChatHistory[]> {
    return await db
      .select()
      .from(chatHistory)
      .where(eq(chatHistory.userId, userId))
      .orderBy(chatHistory.timestamp);
  }

  async saveChatMessage(insertChatMessage: InsertChatHistory): Promise<ChatHistory> {
    const [message] = await db
      .insert(chatHistory)
      .values(insertChatMessage)
      .returning();
    return message;
  }

  async clearChatHistory(userId: number): Promise<void> {
    await db
      .delete(chatHistory)
      .where(eq(chatHistory.userId, userId));
  }
}

export const storage = new DatabaseStorage();
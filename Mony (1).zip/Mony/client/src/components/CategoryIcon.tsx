import { 
  Utensils, Car, Film, Heart, BookOpen, Home, Shirt, DollarSign, 
  Briefcase, TrendingUp, Target, ShoppingCart, Zap, Smartphone, 
  Plane, Gamepad2, Dumbbell, Music, Wrench, Paintbrush, Coffee, 
  Gift, LucideIcon
} from "lucide-react";

interface CategoryIconProps {
  iconName: string;
  className?: string;
  color?: string;
  size?: number;
}

const iconMap: Record<string, LucideIcon> = {
  Utensils,
  Car,
  Film,
  Heart,
  BookOpen,
  Home,
  Shirt,
  DollarSign,
  Briefcase,
  TrendingUp,
  Target,
  ShoppingCart,
  Zap,
  Smartphone,
  Plane,
  Gamepad2,
  Dumbbell,
  Music,
  Wrench,
  Paintbrush,
  Coffee,
  Gift
};

export function CategoryIcon({ iconName, className = "h-4 w-4", color, size }: CategoryIconProps) {
  const IconComponent = iconMap[iconName] || Target;
  
  return (
    <IconComponent 
      className={className} 
      style={color ? { color } : undefined}
      size={size}
    />
  );
}

export function getCategoryIconComponent(iconName: string): LucideIcon {
  return iconMap[iconName] || Target;
}

export { iconMap };
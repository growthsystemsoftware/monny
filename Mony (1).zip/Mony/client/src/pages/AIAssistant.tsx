import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Bot, User, Loader2, RotateCcw } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function AIAssistant() {
  const [inputMessage, setInputMessage] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch chat history from database
  const { data: chatHistory = [], isLoading: historyLoading } = useQuery({
    queryKey: ['/api/chat/history'],
    staleTime: 0, // Always fetch fresh data
  });

  // Convert database format to component format with proper typing
  const messages: ChatMessage[] = Array.isArray(chatHistory) ? chatHistory.map((msg: any) => ({
    role: msg.role,
    content: msg.content,
    timestamp: new Date(msg.timestamp)
  })) : [];

  // Add welcome message if no history exists
  const displayMessages = messages.length === 0 ? [
    {
      role: 'assistant' as const,
      content: `¡Hola! Soy tu **Asistente Financiero Personal**. 

Estoy aquí para ayudarte a:
- 📊 Analizar tus gastos e ingresos
- 💰 Optimizar tu presupuesto
- 🎯 Evaluar el progreso de tus metas
- 💡 Darte consejos personalizados de ahorro

¿En qué puedo ayudarte hoy?`,
      timestamp: new Date()
    }
  ] : messages;

  const chatMutation = useMutation({
    mutationFn: async ({ message }: { message: string }) => {
      return await apiRequest('/api/ai/chat', 'POST', { message });
    },
    onSuccess: () => {
      // Refresh chat history after successful message
      queryClient.invalidateQueries({ queryKey: ['/api/chat/history'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "No pude procesar tu consulta. Por favor, inténtalo de nuevo.",
        variant: "destructive"
      });
    }
  });

  const clearChatMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/chat/history', 'DELETE');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/history'] });
      toast({
        title: "Conversación limpiada",
        description: "Se ha iniciado una nueva conversación",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo limpiar la conversación",
        variant: "destructive",
      });
    }
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim() || chatMutation.isPending) return;
    
    chatMutation.mutate({
      message: inputMessage
    });

    setInputMessage("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    const scrollContainer = scrollAreaRef.current?.querySelector('[data-radix-scroll-area-viewport]');
    if (scrollContainer) {
      scrollContainer.scrollTop = scrollContainer.scrollHeight;
    }
  }, [displayMessages, chatMutation.isPending]);

  const suggestedQuestions = [
    "¿Cómo puedo reducir mis gastos este mes?",
    "Analiza mi situación financiera actual",
    "¿Estoy cumpliendo con mis metas de ahorro?",
    "¿En qué categorías gasto más dinero?",
    "Dame consejos para optimizar mi presupuesto"
  ];

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto min-h-screen flex flex-col">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Asistente IA Financiero</h1>
        <p className="text-muted-foreground">
          Obtén consejos personalizados y análisis inteligentes de tus finanzas
        </p>
      </div>

      <div className="flex flex-col lg:grid lg:grid-cols-3 gap-4 sm:gap-6 flex-1">
        {/* Chat Area */}
        <div className="lg:col-span-2 flex flex-col order-1 lg:order-1">
          <Card className="flex-1 flex flex-col min-h-[60vh] lg:min-h-0">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-lg">
                <div className="flex items-center gap-2">
                  <Bot className="h-5 w-5 text-blue-600" />
                  Chat Financiero
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => clearChatMutation.mutate()}
                  disabled={clearChatMutation.isPending}
                  className="flex items-center gap-2"
                >
                  <RotateCcw className="h-4 w-4" />
                  Nueva conversación
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col p-3 sm:p-6">
              <ScrollArea className="flex-1 pr-2 sm:pr-4" ref={scrollAreaRef}>
                <div className="space-y-3 sm:space-y-4">
                  {displayMessages.map((message, index) => (
                    <div
                      key={index}
                      className={`flex items-start gap-2 sm:gap-3 ${
                        message.role === 'user' ? 'flex-row-reverse' : ''
                      }`}
                    >
                      <div className={`flex-shrink-0 w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center ${
                        message.role === 'user' 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-gray-100 dark:bg-gray-800'
                      }`}>
                        {message.role === 'user' ? (
                          <User className="h-3 w-3 sm:h-4 sm:w-4" />
                        ) : (
                          <Bot className="h-3 w-3 sm:h-4 sm:w-4" />
                        )}
                      </div>
                      <div className={`flex-1 max-w-[85%] sm:max-w-[80%] ${
                        message.role === 'user' ? 'text-right' : ''
                      }`}>
                        <div className={`rounded-lg p-2 sm:p-3 ${
                          message.role === 'user'
                            ? 'bg-blue-600 text-white ml-auto'
                            : 'bg-gray-50 dark:bg-gray-900'
                        }`}>
                          {message.role === 'assistant' ? (
                            <div className="prose prose-sm dark:prose-invert max-w-none">
                              <ReactMarkdown 
                                components={{
                                  p: ({ children }) => <p className="mb-2 last:mb-0 text-base sm:text-lg">{children}</p>,
                                  ul: ({ children }) => <ul className="list-disc list-inside mb-2">{children}</ul>,
                                  ol: ({ children }) => <ol className="list-decimal list-inside mb-2">{children}</ol>,
                                  li: ({ children }) => <li className="mb-1 text-base sm:text-lg">{children}</li>,
                                  strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
                                  em: ({ children }) => <em className="italic">{children}</em>,
                                  code: ({ children }) => <code className="bg-gray-200 dark:bg-gray-700 px-1 py-0.5 rounded text-base">{children}</code>,
                                  h3: ({ children }) => <h3 className="font-semibold text-lg sm:text-2xl mb-2 mt-3 first:mt-0">{children}</h3>,
                                }}
                              >
                                {message.content}
                              </ReactMarkdown>
                            </div>
                          ) : (
                            <p className="text-base sm:text-lg">{message.content}</p>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {message.timestamp.toLocaleTimeString('es-CL', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                  {chatMutation.isPending && (
                    <div className="flex items-start gap-2 sm:gap-3">
                      <div className="flex-shrink-0 w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center bg-gray-100 dark:bg-gray-800">
                        <Bot className="h-3 w-3 sm:h-4 sm:w-4" />
                      </div>
                      <div className="flex-1">
                        <div className="rounded-lg p-2 sm:p-3 bg-gray-50 dark:bg-gray-900">
                          <div className="flex items-center gap-2">
                            <Loader2 className="h-3 w-3 sm:h-4 sm:w-4 animate-spin" />
                            <span className="text-base sm:text-lg text-muted-foreground">
                              Analizando tus datos financieros...
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
              
              <div className="mt-3 sm:mt-4 space-y-2 sm:space-y-3">
                <div className="flex gap-2">
                  <Input
                    placeholder="Escribe tu consulta financiera..."
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="flex-1 text-sm"
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!inputMessage.trim() || chatMutation.isPending}
                    size="icon"
                    className="h-10 w-10"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Quick action buttons */}
                <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-1 sm:gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setInputMessage("Analiza mis gastos y dime dónde estoy desperdiciando dinero")}
                    disabled={chatMutation.isPending}
                    className="text-sm h-auto py-2 px-2"
                  >
                    Analizar gastos
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setInputMessage("¿Cómo puedo acelerar el progreso de mis metas financieras?")}
                    disabled={chatMutation.isPending}
                    className="text-sm h-auto py-2 px-2"
                  >
                    Acelerar metas
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setInputMessage("Dame consejos duros sobre mis hábitos de gasto")}
                    disabled={chatMutation.isPending}
                    className="text-sm h-auto py-2 px-2"
                  >
                    Verdades duras
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setInputMessage("¿Qué alternativas más económicas puedo usar para ahorrar más?")}
                    disabled={chatMutation.isPending}
                    className="text-sm h-auto py-2 px-2"
                  >
                    Alternativas
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setInputMessage("Evalúa mi presupuesto y dime si estoy gastando bien")}
                    disabled={chatMutation.isPending}
                    className="text-xs h-auto py-2 px-2 col-span-2 sm:col-span-1"
                  >
                    Evaluar presupuesto
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setInputMessage("¿En qué categorías debería reducir gastos inmediatamente?")}
                    disabled={chatMutation.isPending}
                    className="text-xs h-auto py-2 px-2 col-span-2 sm:col-span-1"
                  >
                    Reducir gastos
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar with suggestions - Hidden on mobile */}
        <div className="space-y-4 sm:space-y-6 order-2 lg:order-2 hidden lg:block">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Preguntas Sugeridas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {suggestedQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full text-left justify-start h-auto p-3 text-sm"
                  onClick={() => setInputMessage(question)}
                  disabled={chatMutation.isPending}
                >
                  {question}
                </Button>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Capacidades del Asistente</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-sm">Análisis Personalizado</p>
                  <p className="text-xs text-muted-foreground">
                    Basado en tus datos reales de transacciones y presupuestos
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-sm">Consejos de Ahorro</p>
                  <p className="text-xs text-muted-foreground">
                    Recomendaciones específicas para optimizar tus gastos
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-purple-600 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-sm">Seguimiento de Metas</p>
                  <p className="text-xs text-muted-foreground">
                    Evaluación del progreso hacia tus objetivos financieros
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-orange-600 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-sm">Análisis de Patrones</p>
                  <p className="text-xs text-muted-foreground">
                    Identificación de tendencias en tus hábitos financieros
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Privacidad y Seguridad</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Tus datos financieros están protegidos y solo se usan para generar 
                consejos personalizados. El asistente no sugiere inversiones específicas 
                y se enfoca en estrategias de ahorro y control de gastos.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}